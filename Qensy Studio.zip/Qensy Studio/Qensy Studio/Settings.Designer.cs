﻿
namespace Qensy_Studio
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Obsolete]
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new Manina.Windows.Forms.TabControl();
            this.tab1 = new Manina.Windows.Forms.Tab();
            this.General = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel16 = new Guna.UI2.WinForms.Guna2Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel15 = new Guna.UI2.WinForms.Guna2Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.guna2Button15 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2NumericUpDown1 = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.guna2ComboBox3 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2ComboBox2 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tab2 = new Manina.Windows.Forms.Tab();
            this.Update = new Guna.UI2.WinForms.Guna2Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2ProgressBar1 = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tab1.SuspendLayout();
            this.General.SuspendLayout();
            this.guna2Panel10.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2NumericUpDown1)).BeginInit();
            this.tab2.SuspendLayout();
            this.Update.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.White;
            this.guna2Panel1.Controls.Add(this.guna2Button17);
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.Controls.Add(this.guna2Button3);
            resources.ApplyResources(this.guna2Panel1, "guna2Panel1");
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            // 
            // guna2Button17
            // 
            resources.ApplyResources(this.guna2Button17, "guna2Button17");
            this.guna2Button17.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button17.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.BorderRadius = 2;
            this.guna2Button17.BorderThickness = 1;
            this.guna2Button17.CheckedState.Parent = this.guna2Button17;
            this.guna2Button17.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button17.CustomImages.Parent = this.guna2Button17;
            this.guna2Button17.FillColor = System.Drawing.Color.Silver;
            this.guna2Button17.ForeColor = System.Drawing.Color.Black;
            this.guna2Button17.HoverState.Parent = this.guna2Button17;
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.ShadowDecoration.Parent = this.guna2Button17;
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2Button1
            // 
            resources.ApplyResources(this.guna2Button1, "guna2Button1");
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.BorderRadius = 2;
            this.guna2Button1.BorderThickness = 1;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Silver;
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Button3
            // 
            resources.ApplyResources(this.guna2Button3, "guna2Button3");
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.BorderRadius = 2;
            this.guna2Button3.BorderThickness = 1;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.Silver;
            this.guna2Button3.ForeColor = System.Drawing.Color.Black;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tabControl1.Controls.Add(this.tab1);
            this.tabControl1.Controls.Add(this.tab2);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Tabs.Add(this.tab1);
            this.tabControl1.Tabs.Add(this.tab2);
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // tab1
            // 
            this.tab1.BackColor = System.Drawing.Color.Gainsboro;
            this.tab1.Controls.Add(this.General);
            resources.ApplyResources(this.tab1, "tab1");
            this.tab1.Name = "tab1";
            // 
            // General
            // 
            this.General.Controls.Add(this.guna2Panel10);
            this.General.Controls.Add(this.guna2Panel2);
            this.General.Controls.Add(this.guna2Panel4);
            this.General.Controls.Add(this.guna2ComboBox1);
            this.General.Controls.Add(this.label15);
            this.General.Controls.Add(this.guna2ComboBox3);
            this.General.Controls.Add(this.label3);
            this.General.Controls.Add(this.guna2ComboBox2);
            resources.ApplyResources(this.General, "General");
            this.General.Name = "General";
            this.General.ShadowDecoration.Parent = this.General;
            // 
            // guna2Panel10
            // 
            resources.ApplyResources(this.guna2Panel10, "guna2Panel10");
            this.guna2Panel10.BackColor = System.Drawing.Color.LightGray;
            this.guna2Panel10.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel10.BorderThickness = 1;
            this.guna2Panel10.Controls.Add(this.label17);
            this.guna2Panel10.Controls.Add(this.guna2Button19);
            this.guna2Panel10.Controls.Add(this.guna2Panel16);
            this.guna2Panel10.Controls.Add(this.label16);
            this.guna2Panel10.Controls.Add(this.guna2Button18);
            this.guna2Panel10.Controls.Add(this.guna2Panel15);
            this.guna2Panel10.Controls.Add(this.label10);
            this.guna2Panel10.Controls.Add(this.guna2Button13);
            this.guna2Panel10.Controls.Add(this.guna2Panel11);
            this.guna2Panel10.Controls.Add(this.label11);
            this.guna2Panel10.Controls.Add(this.guna2Button14);
            this.guna2Panel10.Controls.Add(this.guna2Panel12);
            this.guna2Panel10.Controls.Add(this.label12);
            this.guna2Panel10.Controls.Add(this.guna2Button15);
            this.guna2Panel10.Controls.Add(this.guna2Button16);
            this.guna2Panel10.Controls.Add(this.guna2Panel13);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.ShadowDecoration.Parent = this.guna2Panel10;
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Name = "label17";
            // 
            // guna2Button19
            // 
            this.guna2Button19.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button19.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button19.BorderRadius = 2;
            this.guna2Button19.BorderThickness = 1;
            this.guna2Button19.CheckedState.Parent = this.guna2Button19;
            this.guna2Button19.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button19.CustomImages.Parent = this.guna2Button19;
            this.guna2Button19.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button19, "guna2Button19");
            this.guna2Button19.ForeColor = System.Drawing.Color.Black;
            this.guna2Button19.HoverState.Parent = this.guna2Button19;
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.ShadowDecoration.Parent = this.guna2Button19;
            this.guna2Button19.Click += new System.EventHandler(this.guna2Button19_Click);
            // 
            // guna2Panel16
            // 
            this.guna2Panel16.BackColor = System.Drawing.Color.Black;
            this.guna2Panel16.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel16.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel16, "guna2Panel16");
            this.guna2Panel16.Name = "guna2Panel16";
            this.guna2Panel16.ShadowDecoration.Parent = this.guna2Panel16;
            this.guna2Panel16.DoubleClick += new System.EventHandler(this.guna2Panel16_DoubleClick);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Name = "label16";
            // 
            // guna2Button18
            // 
            this.guna2Button18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button18.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.BorderRadius = 2;
            this.guna2Button18.BorderThickness = 1;
            this.guna2Button18.CheckedState.Parent = this.guna2Button18;
            this.guna2Button18.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button18.CustomImages.Parent = this.guna2Button18;
            this.guna2Button18.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button18, "guna2Button18");
            this.guna2Button18.ForeColor = System.Drawing.Color.Black;
            this.guna2Button18.HoverState.Parent = this.guna2Button18;
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.ShadowDecoration.Parent = this.guna2Button18;
            this.guna2Button18.Click += new System.EventHandler(this.guna2Button18_Click);
            // 
            // guna2Panel15
            // 
            this.guna2Panel15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel15.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel15.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel15, "guna2Panel15");
            this.guna2Panel15.Name = "guna2Panel15";
            this.guna2Panel15.ShadowDecoration.Parent = this.guna2Panel15;
            this.guna2Panel15.DoubleClick += new System.EventHandler(this.guna2Panel15_DoubleClick);
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Name = "label10";
            // 
            // guna2Button13
            // 
            this.guna2Button13.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button13.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button13.BorderRadius = 2;
            this.guna2Button13.BorderThickness = 1;
            this.guna2Button13.CheckedState.Parent = this.guna2Button13;
            this.guna2Button13.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button13.CustomImages.Parent = this.guna2Button13;
            this.guna2Button13.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button13, "guna2Button13");
            this.guna2Button13.ForeColor = System.Drawing.Color.Black;
            this.guna2Button13.HoverState.Parent = this.guna2Button13;
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.ShadowDecoration.Parent = this.guna2Button13;
            this.guna2Button13.Click += new System.EventHandler(this.guna2Button13_Click);
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Panel11.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel11.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel11, "guna2Panel11");
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.DoubleClick += new System.EventHandler(this.guna2Panel11_DoubleClick);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Name = "label11";
            // 
            // guna2Button14
            // 
            this.guna2Button14.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button14.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button14.BorderRadius = 2;
            this.guna2Button14.BorderThickness = 1;
            this.guna2Button14.CheckedState.Parent = this.guna2Button14;
            this.guna2Button14.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button14.CustomImages.Parent = this.guna2Button14;
            this.guna2Button14.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button14, "guna2Button14");
            this.guna2Button14.ForeColor = System.Drawing.Color.Black;
            this.guna2Button14.HoverState.Parent = this.guna2Button14;
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.ShadowDecoration.Parent = this.guna2Button14;
            this.guna2Button14.Click += new System.EventHandler(this.guna2Button14_Click);
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.BackColor = System.Drawing.Color.Black;
            this.guna2Panel12.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel12.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel12, "guna2Panel12");
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.DoubleClick += new System.EventHandler(this.guna2Panel12_DoubleClick);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Name = "label12";
            // 
            // guna2Button15
            // 
            resources.ApplyResources(this.guna2Button15, "guna2Button15");
            this.guna2Button15.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button15.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button15.BorderRadius = 2;
            this.guna2Button15.BorderThickness = 1;
            this.guna2Button15.CheckedState.Parent = this.guna2Button15;
            this.guna2Button15.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button15.CustomImages.Parent = this.guna2Button15;
            this.guna2Button15.FillColor = System.Drawing.Color.Silver;
            this.guna2Button15.ForeColor = System.Drawing.Color.Black;
            this.guna2Button15.HoverState.Parent = this.guna2Button15;
            this.guna2Button15.Name = "guna2Button15";
            this.guna2Button15.ShadowDecoration.Parent = this.guna2Button15;
            this.guna2Button15.Click += new System.EventHandler(this.guna2Button15_Click);
            // 
            // guna2Button16
            // 
            this.guna2Button16.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button16.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.BorderRadius = 2;
            this.guna2Button16.BorderThickness = 1;
            this.guna2Button16.CheckedState.Parent = this.guna2Button16;
            this.guna2Button16.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button16.CustomImages.Parent = this.guna2Button16;
            this.guna2Button16.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button16, "guna2Button16");
            this.guna2Button16.ForeColor = System.Drawing.Color.Black;
            this.guna2Button16.HoverState.Parent = this.guna2Button16;
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.ShadowDecoration.Parent = this.guna2Button16;
            this.guna2Button16.Click += new System.EventHandler(this.guna2Button16_Click);
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.BackColor = System.Drawing.SystemColors.Window;
            this.guna2Panel13.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel13.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel13, "guna2Panel13");
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.DoubleClick += new System.EventHandler(this.guna2Panel13_DoubleClick);
            // 
            // guna2Panel2
            // 
            resources.ApplyResources(this.guna2Panel2, "guna2Panel2");
            this.guna2Panel2.BackColor = System.Drawing.Color.LightGray;
            this.guna2Panel2.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel2.BorderThickness = 1;
            this.guna2Panel2.Controls.Add(this.label14);
            this.guna2Panel2.Controls.Add(this.guna2Button4);
            this.guna2Panel2.Controls.Add(this.guna2Panel14);
            this.guna2Panel2.Controls.Add(this.label7);
            this.guna2Panel2.Controls.Add(this.guna2Button5);
            this.guna2Panel2.Controls.Add(this.guna2Panel3);
            this.guna2Panel2.Controls.Add(this.label8);
            this.guna2Panel2.Controls.Add(this.guna2Button6);
            this.guna2Panel2.Controls.Add(this.guna2Panel8);
            this.guna2Panel2.Controls.Add(this.label9);
            this.guna2Panel2.Controls.Add(this.guna2Button11);
            this.guna2Panel2.Controls.Add(this.guna2Button12);
            this.guna2Panel2.Controls.Add(this.guna2Panel9);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Name = "label14";
            // 
            // guna2Button4
            // 
            this.guna2Button4.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button4.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.BorderRadius = 2;
            this.guna2Button4.BorderThickness = 1;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button4, "guna2Button4");
            this.guna2Button4.ForeColor = System.Drawing.Color.Black;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.SystemColors.Window;
            this.guna2Panel14.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel14.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel14, "guna2Panel14");
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.ShadowDecoration.Parent = this.guna2Panel14;
            this.guna2Panel14.DoubleClick += new System.EventHandler(this.guna2Panel14_DoubleClick);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Name = "label7";
            // 
            // guna2Button5
            // 
            this.guna2Button5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button5.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.BorderRadius = 2;
            this.guna2Button5.BorderThickness = 1;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button5, "guna2Button5");
            this.guna2Button5.ForeColor = System.Drawing.Color.Black;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BackColor = System.Drawing.Color.White;
            this.guna2Panel3.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel3.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel3, "guna2Panel3");
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.DoubleClick += new System.EventHandler(this.guna2Panel3_DoubleClick);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Name = "label8";
            // 
            // guna2Button6
            // 
            this.guna2Button6.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button6.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.BorderRadius = 2;
            this.guna2Button6.BorderThickness = 1;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button6, "guna2Button6");
            this.guna2Button6.ForeColor = System.Drawing.Color.Black;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Click += new System.EventHandler(this.guna2Button6_Click);
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.BackColor = System.Drawing.Color.Black;
            this.guna2Panel8.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel8.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel8, "guna2Panel8");
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.DoubleClick += new System.EventHandler(this.guna2Panel8_DoubleClick);
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Name = "label9";
            // 
            // guna2Button11
            // 
            resources.ApplyResources(this.guna2Button11, "guna2Button11");
            this.guna2Button11.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button11.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button11.BorderRadius = 2;
            this.guna2Button11.BorderThickness = 1;
            this.guna2Button11.CheckedState.Parent = this.guna2Button11;
            this.guna2Button11.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button11.CustomImages.Parent = this.guna2Button11;
            this.guna2Button11.FillColor = System.Drawing.Color.Silver;
            this.guna2Button11.ForeColor = System.Drawing.Color.Black;
            this.guna2Button11.HoverState.Parent = this.guna2Button11;
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.ShadowDecoration.Parent = this.guna2Button11;
            this.guna2Button11.Click += new System.EventHandler(this.guna2Button11_Click);
            // 
            // guna2Button12
            // 
            this.guna2Button12.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button12.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button12.BorderRadius = 2;
            this.guna2Button12.BorderThickness = 1;
            this.guna2Button12.CheckedState.Parent = this.guna2Button12;
            this.guna2Button12.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button12.CustomImages.Parent = this.guna2Button12;
            this.guna2Button12.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button12, "guna2Button12");
            this.guna2Button12.ForeColor = System.Drawing.Color.Black;
            this.guna2Button12.HoverState.Parent = this.guna2Button12;
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.ShadowDecoration.Parent = this.guna2Button12;
            this.guna2Button12.Click += new System.EventHandler(this.guna2Button12_Click);
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.guna2Panel9.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel9.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel9, "guna2Panel9");
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.DoubleClick += new System.EventHandler(this.guna2Panel9_DoubleClick);
            // 
            // guna2Panel4
            // 
            resources.ApplyResources(this.guna2Panel4, "guna2Panel4");
            this.guna2Panel4.BackColor = System.Drawing.Color.LightGray;
            this.guna2Panel4.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel4.BorderThickness = 1;
            this.guna2Panel4.Controls.Add(this.guna2NumericUpDown1);
            this.guna2Panel4.Controls.Add(this.label13);
            this.guna2Panel4.Controls.Add(this.label6);
            this.guna2Panel4.Controls.Add(this.guna2Button10);
            this.guna2Panel4.Controls.Add(this.guna2Panel7);
            this.guna2Panel4.Controls.Add(this.label5);
            this.guna2Panel4.Controls.Add(this.guna2Button9);
            this.guna2Panel4.Controls.Add(this.guna2Panel6);
            this.guna2Panel4.Controls.Add(this.label4);
            this.guna2Panel4.Controls.Add(this.guna2Button7);
            this.guna2Panel4.Controls.Add(this.guna2Button8);
            this.guna2Panel4.Controls.Add(this.guna2Panel5);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.ShadowDecoration.Parent = this.guna2Panel4;
            // 
            // guna2NumericUpDown1
            // 
            this.guna2NumericUpDown1.BackColor = System.Drawing.Color.Transparent;
            this.guna2NumericUpDown1.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2NumericUpDown1.BorderRadius = 2;
            this.guna2NumericUpDown1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2NumericUpDown1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2NumericUpDown1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2NumericUpDown1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2NumericUpDown1.DisabledState.Parent = this.guna2NumericUpDown1;
            this.guna2NumericUpDown1.DisabledState.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(177)))), ((int)(((byte)(177)))));
            this.guna2NumericUpDown1.DisabledState.UpDownButtonForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(203)))), ((int)(((byte)(203)))));
            this.guna2NumericUpDown1.FillColor = System.Drawing.Color.Silver;
            this.guna2NumericUpDown1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2NumericUpDown1.FocusedState.Parent = this.guna2NumericUpDown1;
            resources.ApplyResources(this.guna2NumericUpDown1, "guna2NumericUpDown1");
            this.guna2NumericUpDown1.ForeColor = System.Drawing.Color.Black;
            this.guna2NumericUpDown1.Maximum = new decimal(new int[] {
            17,
            0,
            0,
            0});
            this.guna2NumericUpDown1.Name = "guna2NumericUpDown1";
            this.guna2NumericUpDown1.ShadowDecoration.Parent = this.guna2NumericUpDown1;
            this.guna2NumericUpDown1.UpDownButtonFillColor = System.Drawing.Color.Silver;
            this.guna2NumericUpDown1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Name = "label13";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Name = "label6";
            // 
            // guna2Button10
            // 
            this.guna2Button10.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button10.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button10.BorderRadius = 2;
            this.guna2Button10.BorderThickness = 1;
            this.guna2Button10.CheckedState.Parent = this.guna2Button10;
            this.guna2Button10.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button10.CustomImages.Parent = this.guna2Button10;
            this.guna2Button10.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button10, "guna2Button10");
            this.guna2Button10.ForeColor = System.Drawing.Color.Black;
            this.guna2Button10.HoverState.Parent = this.guna2Button10;
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.ShadowDecoration.Parent = this.guna2Button10;
            this.guna2Button10.Click += new System.EventHandler(this.guna2Button10_Click);
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.BackColor = System.Drawing.Color.DarkGray;
            this.guna2Panel7.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel7.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel7, "guna2Panel7");
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.DoubleClick += new System.EventHandler(this.guna2Panel7_DoubleClick);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Name = "label5";
            // 
            // guna2Button9
            // 
            this.guna2Button9.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button9.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button9.BorderRadius = 2;
            this.guna2Button9.BorderThickness = 1;
            this.guna2Button9.CheckedState.Parent = this.guna2Button9;
            this.guna2Button9.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button9.CustomImages.Parent = this.guna2Button9;
            this.guna2Button9.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button9, "guna2Button9");
            this.guna2Button9.ForeColor = System.Drawing.Color.Black;
            this.guna2Button9.HoverState.Parent = this.guna2Button9;
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.ShadowDecoration.Parent = this.guna2Button9;
            this.guna2Button9.Click += new System.EventHandler(this.guna2Button9_Click);
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.BackColor = System.Drawing.Color.Black;
            this.guna2Panel6.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel6.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel6, "guna2Panel6");
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.DoubleClick += new System.EventHandler(this.guna2Panel6_DoubleClick);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Name = "label4";
            // 
            // guna2Button7
            // 
            resources.ApplyResources(this.guna2Button7, "guna2Button7");
            this.guna2Button7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button7.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.BorderRadius = 2;
            this.guna2Button7.BorderThickness = 1;
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.Silver;
            this.guna2Button7.ForeColor = System.Drawing.Color.Black;
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // guna2Button8
            // 
            this.guna2Button8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button8.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.BorderRadius = 2;
            this.guna2Button8.BorderThickness = 1;
            this.guna2Button8.CheckedState.Parent = this.guna2Button8;
            this.guna2Button8.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button8.CustomImages.Parent = this.guna2Button8;
            this.guna2Button8.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button8, "guna2Button8");
            this.guna2Button8.ForeColor = System.Drawing.Color.Black;
            this.guna2Button8.HoverState.Parent = this.guna2Button8;
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.ShadowDecoration.Parent = this.guna2Button8;
            this.guna2Button8.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BackColor = System.Drawing.Color.Silver;
            this.guna2Panel5.BorderColor = System.Drawing.Color.DimGray;
            this.guna2Panel5.BorderThickness = 1;
            resources.ApplyResources(this.guna2Panel5, "guna2Panel5");
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.DoubleClick += new System.EventHandler(this.guna2Panel5_DoubleClick);
            // 
            // guna2ComboBox1
            // 
            resources.ApplyResources(this.guna2ComboBox1, "guna2ComboBox1");
            this.guna2ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox1.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ComboBox1.BorderRadius = 2;
            this.guna2ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox1.FillColor = System.Drawing.Color.Silver;
            this.guna2ComboBox1.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox1.FocusedState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2ComboBox1.FormattingEnabled = true;
            this.guna2ComboBox1.HoverState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Items.AddRange(new object[] {
            resources.GetString("guna2ComboBox1.Items"),
            resources.GetString("guna2ComboBox1.Items1")});
            this.guna2ComboBox1.ItemsAppearance.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Name = "guna2ComboBox1";
            this.guna2ComboBox1.ShadowDecoration.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.StartIndex = 0;
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // guna2ComboBox3
            // 
            resources.ApplyResources(this.guna2ComboBox3, "guna2ComboBox3");
            this.guna2ComboBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox3.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ComboBox3.BorderRadius = 2;
            this.guna2ComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox3.FillColor = System.Drawing.Color.Silver;
            this.guna2ComboBox3.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox3.FocusedState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.ForeColor = System.Drawing.Color.Black;
            this.guna2ComboBox3.FormattingEnabled = true;
            this.guna2ComboBox3.HoverState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.ItemsAppearance.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Name = "guna2ComboBox3";
            this.guna2ComboBox3.ShadowDecoration.Parent = this.guna2ComboBox3;
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // guna2ComboBox2
            // 
            this.guna2ComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox2.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2ComboBox2.BorderRadius = 2;
            this.guna2ComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox2.FillColor = System.Drawing.Color.Silver;
            this.guna2ComboBox2.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox2.FocusedState.Parent = this.guna2ComboBox2;
            resources.ApplyResources(this.guna2ComboBox2, "guna2ComboBox2");
            this.guna2ComboBox2.ForeColor = System.Drawing.Color.Black;
            this.guna2ComboBox2.FormattingEnabled = true;
            this.guna2ComboBox2.HoverState.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Items.AddRange(new object[] {
            resources.GetString("guna2ComboBox2.Items"),
            resources.GetString("guna2ComboBox2.Items1"),
            resources.GetString("guna2ComboBox2.Items2")});
            this.guna2ComboBox2.ItemsAppearance.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Name = "guna2ComboBox2";
            this.guna2ComboBox2.ShadowDecoration.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.StartIndex = 0;
            this.guna2ComboBox2.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox2_SelectedIndexChanged);
            // 
            // tab2
            // 
            this.tab2.BackColor = System.Drawing.Color.Gainsboro;
            this.tab2.Controls.Add(this.Update);
            resources.ApplyResources(this.tab2, "tab2");
            this.tab2.Name = "tab2";
            // 
            // Update
            // 
            this.Update.Controls.Add(this.label2);
            this.Update.Controls.Add(this.label1);
            this.Update.Controls.Add(this.guna2ProgressBar1);
            this.Update.Controls.Add(this.guna2Button2);
            resources.ApplyResources(this.Update, "Update");
            this.Update.Name = "Update";
            this.Update.ShadowDecoration.Parent = this.Update;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // guna2ProgressBar1
            // 
            resources.ApplyResources(this.guna2ProgressBar1, "guna2ProgressBar1");
            this.guna2ProgressBar1.FillColor = System.Drawing.Color.Gray;
            this.guna2ProgressBar1.ForeColor = System.Drawing.Color.White;
            this.guna2ProgressBar1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.guna2ProgressBar1.Name = "guna2ProgressBar1";
            this.guna2ProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.guna2ProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.guna2ProgressBar1.ShadowDecoration.Parent = this.guna2ProgressBar1;
            this.guna2ProgressBar1.ShowPercentage = true;
            this.guna2ProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // guna2Button2
            // 
            this.guna2Button2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button2.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.BorderRadius = 2;
            this.guna2Button2.BorderThickness = 1;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomBorderColor = System.Drawing.Color.Silver;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.guna2Button2, "guna2Button2");
            this.guna2Button2.ForeColor = System.Drawing.Color.Black;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // Settings
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Settings";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Load += new System.EventHandler(this.Settings_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.General.ResumeLayout(false);
            this.General.PerformLayout();
            this.guna2Panel10.ResumeLayout(false);
            this.guna2Panel10.PerformLayout();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.guna2Panel4.ResumeLayout(false);
            this.guna2Panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2NumericUpDown1)).EndInit();
            this.tab2.ResumeLayout(false);
            this.Update.ResumeLayout(false);
            this.Update.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        public Guna.UI2.WinForms.Guna2Button guna2Button1;
        public Guna.UI2.WinForms.Guna2Button guna2Button3;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Timer timer1;
        public Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Manina.Windows.Forms.TabControl tabControl1;
        private Manina.Windows.Forms.Tab tab1;
        private Manina.Windows.Forms.Tab tab2;
        private Guna.UI2.WinForms.Guna2Panel General;
        private new Guna.UI2.WinForms.Guna2Panel Update;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ProgressBar guna2ProgressBar1;
        public Guna.UI2.WinForms.Guna2Button guna2Button2;
        public Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private System.Windows.Forms.Label label15;
        public Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox3;
        private System.Windows.Forms.Label label3;
        public Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Label label14;
        public Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private System.Windows.Forms.Label label7;
        public Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private System.Windows.Forms.Label label8;
        public Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private System.Windows.Forms.Label label9;
        public Guna.UI2.WinForms.Guna2Button guna2Button11;
        public Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2NumericUpDown guna2NumericUpDown1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        public Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private System.Windows.Forms.Label label5;
        public Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private System.Windows.Forms.Label label4;
        public Guna.UI2.WinForms.Guna2Button guna2Button7;
        public Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private System.Windows.Forms.Label label10;
        public Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private System.Windows.Forms.Label label11;
        public Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private System.Windows.Forms.Label label12;
        public Guna.UI2.WinForms.Guna2Button guna2Button15;
        public Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private System.Windows.Forms.Label label16;
        public Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel15;
        private System.Windows.Forms.Label label17;
        public Guna.UI2.WinForms.Guna2Button guna2Button19;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel16;
    }
}