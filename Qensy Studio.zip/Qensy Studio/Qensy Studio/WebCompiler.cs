﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qensy_Studio
{
    public partial class WebCompiler : Form
    {

        string text = "";
        [Obsolete]
        public WebCompiler(string T)
        {
            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {               
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }
            InitializeComponent();
            text = T;
        }

        [Obsolete]
        private void WebCompiler_Load(object sender, EventArgs e)
        {
            webBrowser1.DocumentText = text;
            if (Properties.Settings.Default.Theme == 0)
            {
                BackColor = Color.White;
                guna2Button3.FillColor = Color.WhiteSmoke;
                guna2Button3.ForeColor = Color.Black;
                guna2Panel1.FillColor = Color.WhiteSmoke;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                BackColor = Color.DimGray;
                guna2Button3.FillColor = Color.FromArgb(40, 40, 40);
                guna2Button3.ForeColor = Color.White;
                guna2Panel1.FillColor = Color.FromArgb(40, 40, 40);
            }
        }

        [Obsolete]
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        
    }
}
