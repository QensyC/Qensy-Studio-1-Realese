﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Qensy_Studio
{
    public partial class About : Form
    {
        public About()
        {

            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void About_Load(object sender, EventArgs e)
        {
            guna2Button1.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button1.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button1.BorderRadius = Properties.Settings.Default.butradius;

            if (Properties.Settings.Default.Theme == 0)
            {
                BackColor = Color.White;
                label1.ForeColor = Color.Black;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                textBox1.ForeColor = Color.Black;
                textBox1.BackColor = Color.WhiteSmoke;
                guna2Panel1.FillColor = Color.WhiteSmoke;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                BackColor = Color.DimGray;
                label1.ForeColor = Color.White;
                label2.ForeColor = Color.White;
                label3.ForeColor = Color.White;
                label4.ForeColor = Color.White;
                textBox1.ForeColor = Color.White;
                textBox1.BackColor = Color.FromArgb(60, 60, 60);
                guna2Panel1.FillColor = Color.FromArgb(70, 70, 70);
            }
        }
    }
}
