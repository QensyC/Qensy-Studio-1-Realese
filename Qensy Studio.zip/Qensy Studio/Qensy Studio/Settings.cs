﻿using System;
using System.Drawing;
using System.Net;
using System.Windows.Forms;

namespace Qensy_Studio
{
    public partial class Settings : Form
    {
        [Obsolete]
        public Settings()
        {            
            

            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }
            InitializeComponent();

            
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        [Obsolete]
        private void Settings_Load(object sender, EventArgs e)
        {
            guna2ComboBox3.DataSource = new System.Globalization.CultureInfo[]{
            System.Globalization.CultureInfo.GetCultureInfo("ru-RU"),
            System.Globalization.CultureInfo.GetCultureInfo("en-US")

            };

            guna2ComboBox3.DisplayMember = "NativeName"; 
            guna2ComboBox3.ValueMember = "Name"; 

            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                guna2ComboBox3.SelectedValue = Properties.Settings.Default.Language;
            }



            guna2ComboBox1.SelectedIndex = Properties.Settings.Default.Theme;

            if (guna2ComboBox1.SelectedIndex == 0)
            {
                BackColor = Color.White;
                tab1.BackColor = Color.Gainsboro;
                tab2.BackColor = Color.Gainsboro;
                tab1.ForeColor = Color.Black;
                tab2.ForeColor = Color.Black;
                guna2Panel1.BackColor = Color.White;
                guna2ProgressBar1.FillColor = Color.Gray;
                guna2ProgressBar1.ForeColor = Color.White;
                guna2Panel10.FillColor = Color.LightGray;
                guna2Panel4.FillColor = Color.LightGray;
                guna2Panel2.FillColor = Color.LightGray;
            }
            else if (guna2ComboBox1.SelectedIndex == 1)
            {
               
                BackColor = Color.DimGray;
                tab1.BackColor = Color.Gray;
                tab2.BackColor = Color.Gray;
                tab1.ForeColor = Color.White;
                tab2.ForeColor = Color.White;
                guna2Panel1.BackColor = Color.DimGray;
                guna2ProgressBar1.FillColor = Color.Silver;
                guna2ProgressBar1.ForeColor = Color.Black;
                guna2Panel10.FillColor = Color.DimGray;
                guna2Panel4.FillColor = Color.DimGray;
                guna2Panel2.FillColor = Color.DimGray;

            }

            guna2Panel9.FillColor = Properties.Settings.Default.autocolor;
            guna2Panel5.FillColor = Properties.Settings.Default.fillcolor;
            guna2Panel6.FillColor = Properties.Settings.Default.forecolor;
            guna2Panel7.FillColor = Properties.Settings.Default.bordercolor;
            guna2Panel3.FillColor = Properties.Settings.Default.autoborder;
            guna2Panel8.FillColor = Properties.Settings.Default.autofore;
            guna2Panel14.FillColor = Properties.Settings.Default.autonotselectbg;
            guna2Panel13.FillColor = Properties.Settings.Default.editorback;
            guna2Panel12.FillColor = Properties.Settings.Default.editorfore;
            guna2Panel11.FillColor = Properties.Settings.Default.editorsel;
            guna2Panel15.FillColor = Properties.Settings.Default.linecolor;
            guna2Panel16.FillColor = Properties.Settings.Default.lineforecolor;
            guna2NumericUpDown1.Value = Properties.Settings.Default.butradius;
            
            guna2Button1.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button1.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button1.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button2.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button2.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button2.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button3.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button3.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button3.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button3.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button4.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button4.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button4.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button4.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button5.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button5.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button5.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button5.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button6.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button6.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button6.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button6.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button7.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button7.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button7.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button7.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button8.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button8.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button8.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button8.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button9.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button9.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button9.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button9.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button10.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button10.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button10.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button10.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button11.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button11.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button11.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button11.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button12.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button12.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button12.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button12.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button13.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button13.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button13.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button13.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button14.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button14.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button14.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button14.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button15.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button15.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button15.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button15.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button16.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button16.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button16.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button16.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button17.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button17.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button17.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button17.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button18.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button18.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button18.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button18.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button19.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button19.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button19.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button19.BorderRadius = Properties.Settings.Default.butradius;

            guna2ComboBox1.FillColor = Properties.Settings.Default.fillcolor;
            guna2ComboBox1.ForeColor = Properties.Settings.Default.forecolor;
            guna2ComboBox1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2ComboBox1.BorderRadius = Properties.Settings.Default.butradius;

            guna2ComboBox2.FillColor = Properties.Settings.Default.fillcolor;
            guna2ComboBox2.ForeColor = Properties.Settings.Default.forecolor;
            guna2ComboBox2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2ComboBox2.BorderRadius = Properties.Settings.Default.butradius;

            guna2ComboBox3.FillColor = Properties.Settings.Default.fillcolor;
            guna2ComboBox3.ForeColor = Properties.Settings.Default.forecolor;
            guna2ComboBox3.BorderColor = Properties.Settings.Default.bordercolor;
            guna2ComboBox3.BorderRadius = Properties.Settings.Default.butradius;

            
            guna2NumericUpDown1.FillColor = Properties.Settings.Default.fillcolor;
            guna2NumericUpDown1.ForeColor = Properties.Settings.Default.forecolor;
            guna2NumericUpDown1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2NumericUpDown1.BorderRadius = Properties.Settings.Default.butradius;
            guna2NumericUpDown1.UpDownButtonForeColor = Properties.Settings.Default.forecolor;
            guna2NumericUpDown1.UpDownButtonFillColor = Properties.Settings.Default.fillcolor;

        }

        [Obsolete]
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {
                DialogResult dg = MessageBox.Show(MyStrings._1text, MyStrings._1title, MessageBoxButtons.YesNo);
                if (dg == DialogResult.Yes)
                {
                    if(guna2ComboBox1.SelectedIndex == 0)
                    {
                        Properties.Settings.Default.Theme = 0;
                    }
                    else if (guna2ComboBox1.SelectedIndex == 1)
                    {
                        Properties.Settings.Default.Theme = 1;
                    }
                    Properties.Settings.Default.autocolor = guna2Panel9.FillColor;
                    Properties.Settings.Default.fillcolor = guna2Panel5.FillColor;
                    Properties.Settings.Default.forecolor = guna2Panel6.FillColor;
                    Properties.Settings.Default.bordercolor = guna2Panel7.FillColor;
                    Properties.Settings.Default.autoborder = guna2Panel3.FillColor;
                    Properties.Settings.Default.autofore = guna2Panel8.FillColor;
                    Properties.Settings.Default.autonotselectbg = guna2Panel14.FillColor;
                    Properties.Settings.Default.editorback = guna2Panel13.FillColor;
                    Properties.Settings.Default.editorfore = guna2Panel12.FillColor;
                    Properties.Settings.Default.editorsel = guna2Panel11.FillColor;
                    Properties.Settings.Default.butradius = (int)guna2NumericUpDown1.Value;
                    Properties.Settings.Default.Language = guna2ComboBox3.SelectedValue.ToString();
                    Properties.Settings.Default.linecolor = guna2Panel15.FillColor;
                    Properties.Settings.Default.lineforecolor = guna2Panel16.FillColor;
                    Properties.Settings.Default.Save();
                    Application.Exit();
                    Application.Restart();
                }
                else if (dg == DialogResult.No)
                {
                    return;
                }
            }
            else if(tabControl1.SelectedIndex == 1)
            {
                WebClient client = new WebClient();
                if(guna2ProgressBar1.Value == 100)
                {
                    if (client.DownloadString("https://pastebin.com/raw/gHbEsS86").Contains("1.0"))
                    {
                        label2.ForeColor = Color.Red;
                        label2.Text = MyStrings._14title;
                    }
                    else
                    {
                        label2.ForeColor = Color.Black;
                        label2.Text = MyStrings._13title;
                    }
                }
                if(guna2ProgressBar1.Value > 100)
                {
                    guna2Button2.PerformClick();
                }
            }
            

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            WebClient client = new WebClient();
            if (guna2ProgressBar1.Value > 100)
            {
                timer1.Enabled = false;           
            }             
            else
            {
                guna2ProgressBar1.Value += 1;               
            }              
            if(guna2ProgressBar1.Value == 100)
            {
                timer1.Enabled = false;
                if (client.DownloadString("https://pastebin.com/raw/gHbEsS86").Contains("1.0"))
                {
                    label2.Text = MyStrings._14title;
                }
                else
                {
                    label2.Text = MyStrings._13title;
                }
            }
        }

        private void guna2Button17_Click(object sender, EventArgs e)
        {
            
            guna2Panel13.FillColor = Color.FromKnownColor(KnownColor.Window);
            guna2Panel12.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel11.FillColor = Color.FromArgb(60, 0, 0, 0);
            guna2Panel5.FillColor = Color.FromKnownColor(KnownColor.Silver);
            guna2Panel6.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel7.FillColor = Color.FromKnownColor(KnownColor.DarkGray);
            guna2NumericUpDown1.Value = 2;
            guna2Panel3.FillColor = Color.FromKnownColor(KnownColor.White);
            guna2Panel14.FillColor = Color.FromKnownColor(KnownColor.White);
            guna2Panel15.FillColor = Color.WhiteSmoke;
            guna2Panel16.FillColor = Color.Black;
            guna2Panel8.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel9.FillColor = Color.FromKnownColor(KnownColor.MenuHighlight);
            guna2ComboBox1.SelectedIndex = 0;
            Properties.Settings.Default.Reset();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
            label2.Text = MyStrings._15title;
        }

        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (guna2ComboBox2.SelectedIndex == 0)
            {
                guna2Panel4.Visible = false;
                guna2Panel2.Visible = true;
                guna2Panel10.Visible = false;
            }
            else if (guna2ComboBox2.SelectedIndex == 1)
            {
                guna2Panel4.Visible = true;
                guna2Panel2.Visible = false;
                guna2Panel10.Visible = false;
            }
            else if (guna2ComboBox2.SelectedIndex == 2)
            {
                guna2Panel4.Visible = false;
                guna2Panel2.Visible = false;
                guna2Panel10.Visible = true;
            }
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 1)
            {
                guna2Button3.Text = MyStrings._11title;
            }

            if (tabControl1.SelectedIndex == 0)
            {
                guna2Button3.Text = MyStrings._12title;
            }
        }

        [Obsolete]
        private void guna2Button5_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel3.FillColor = colorDialog1.Color;
                TextBoxEditor textBoxEditor = new TextBoxEditor();
                textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor = colorDialog1.Color;
                textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor2 = colorDialog1.Color;
            }
        }

        [Obsolete]
        private void guna2Panel3_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel3.FillColor = colorDialog1.Color;
                TextBoxEditor textBoxEditor = new TextBoxEditor();
                textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor = colorDialog1.Color;
                textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor2 = colorDialog1.Color;

            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel14.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel14_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel14.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel5.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel5_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel5.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel6.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel7.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel6_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel6.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel7_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel7.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            guna2Panel5.FillColor = Color.FromKnownColor(KnownColor.Silver);
            guna2Panel6.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel7.FillColor = Color.FromKnownColor(KnownColor.DarkGray);
            guna2NumericUpDown1.Value = 2;
        }

        private void guna2Button12_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel9.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel8.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel9_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel9.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel8_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel8.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            guna2Panel3.FillColor = Color.FromKnownColor(KnownColor.White);
            guna2Panel14.FillColor = Color.FromKnownColor(KnownColor.White);
            guna2Panel8.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel9.FillColor = Color.FromKnownColor(KnownColor.MenuHighlight);
        }

        private void guna2Panel13_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel13.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel12_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel12.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel11_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel11.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button16_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel13.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button14_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel12.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button13_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel11.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button15_Click(object sender, EventArgs e)
        {
            guna2Panel13.FillColor = Color.FromKnownColor(KnownColor.Window);
            guna2Panel12.FillColor = Color.FromKnownColor(KnownColor.Black);
            guna2Panel11.FillColor = Color.FromArgb(60, 0, 0, 0);
            guna2Panel15.FillColor = Color.WhiteSmoke;
            guna2Panel16.FillColor = Color.Black;
        }

        private void guna2Panel15_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel15.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button18_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel15.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Panel16_DoubleClick(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel16.FillColor = colorDialog1.Color;
            }
        }

        private void guna2Button19_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                guna2Panel16.FillColor = colorDialog1.Color;
            }
        }
    }
}
