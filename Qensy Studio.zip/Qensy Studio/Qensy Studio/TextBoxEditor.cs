﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using Microsoft.CSharp;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;

namespace Qensy_Studio
{
    public partial class TextBoxEditor : UserControl
    {
        [Obsolete]
        public TextBoxEditor()
        {
            InitializeComponent();           
            if (BoxEditor.Language == Language.CSharp)
            {
                s.Visible = true;
            }
            else if (BoxEditor.Language == Language.VB)
            {
                s.Visible = true;
            }
            else
            {
                s.Visible = false;
            }
            Errorbtn.Text = "";
            documentMap1.Dock = Properties.Settings.Default.MapDock;
            splitter1.Dock = Properties.Settings.Default.MapDock;
            documentMap1.Size = Properties.Settings.Default.MapSize;
            guna2Panel6.Size = Properties.Settings.Default.OutSize;
            guna2Panel6.Dock = Properties.Settings.Default.OutDock;
            splitter3.Dock = Properties.Settings.Default.OutDock;
            splitter3.Cursor = Properties.Settings.Default.OutCursor;
            BoxEditor.LineNumberColor = Properties.Settings.Default.lineforecolor;
            BoxEditor.IndentBackColor = Properties.Settings.Default.linecolor;
            Properties.Settings.Default.Save();

            autocompleteMenu1.SetAutocompleteItems(new DynamicCollection(autocompleteMenu1, BoxEditor));
        }



        [Obsolete]
        private void StartBtn_Click(object sender, EventArgs e)
        {
            if(BoxEditor.Language == Language.CSharp)
            {         
                
                CSharpCodeProvider codeProvider = new CSharpCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);
                OutputBox.Clear();

                if (results.Errors.Count > 0)
                {
                    OutputBox.Clear();
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                        Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                    }
                }
                else
                {
                    OutputBox.Clear();
                    Errorbtn.Text = "";
                    Process.Start(Output);

                }
            }
            else if (BoxEditor.Language == Language.VB)
            {
                VBCodeProvider codeProvider = new VBCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);
                OutputBox.Clear();

                if (results.Errors.Count > 0)
                {
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        OutputBox.Clear();
                        OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                        Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                    }
                }
                else
                {
                    OutputBox.Clear();
                    Errorbtn.Text = "";
                    Process.Start(Output);
                }
            }            
            else if (BoxEditor.Language == Language.HTML)
            {
                WebCompiler webCompiler = new WebCompiler(BoxEditor.Text);
                webCompiler.ShowDialog();

            }
        }

        private void topToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel6.Dock = DockStyle.Top;
            splitter3.Dock = DockStyle.Top;
            splitter3.Cursor = Cursors.SizeNS;
            guna2Panel6.Size = new Size(606, 141);
            Properties.Settings.Default.OutCursor = splitter3.Cursor;
            Properties.Settings.Default.OutDock = guna2Panel6.Dock;
            Properties.Settings.Default.OutDock = splitter3.Dock;
            Properties.Settings.Default.Save();

        }

        private void leftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel6.Dock = DockStyle.Left;
            splitter3.Dock = DockStyle.Left;
            splitter3.Cursor = Cursors.SizeWE;
            guna2Panel6.Size = new Size(150, 795);
            Properties.Settings.Default.OutCursor = splitter3.Cursor;
            Properties.Settings.Default.OutDock = guna2Panel6.Dock;
            Properties.Settings.Default.OutDock = splitter3.Dock;
            Properties.Settings.Default.Save();
        }

        private void rightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel6.Dock = DockStyle.Right;
            splitter3.Dock = DockStyle.Right;
            splitter3.Cursor = Cursors.SizeWE;
            guna2Panel6.Size = new Size(150, 795);
            Properties.Settings.Default.OutCursor = splitter3.Cursor;
            Properties.Settings.Default.OutDock = guna2Panel6.Dock;
            Properties.Settings.Default.OutDock = splitter3.Dock;
            Properties.Settings.Default.Save();
        }

        private void bottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel6.Dock = DockStyle.Bottom;
            splitter3.Dock = DockStyle.Bottom;
            splitter3.Cursor = Cursors.SizeNS;
            guna2Panel6.Size = new Size(606, 141);
            Properties.Settings.Default.OutCursor = splitter3.Cursor;
            Properties.Settings.Default.OutDock = guna2Panel6.Dock;
            Properties.Settings.Default.OutDock = splitter3.Dock;
            Properties.Settings.Default.Save();
        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {
            Clipboard.Clear();
            Clipboard.SetText(toolStripStatusLabel2.Text);
            MessageBox.Show(MyStrings._9text, MyStrings._9title, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        [Obsolete]
        private void BoxEditor_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = BoxEditor.Text;
            string[] lines = text.Split('\n');
            toolStripStatusLabel6.Text = text.Length.ToString();
            toolStripStatusLabel4.Text = lines.Length.ToString();
            //clear folding markers of changed range
            e.ChangedRange.ClearFoldingMarkers();
            //set folding markers
            e.ChangedRange.SetFoldingMarkers("{", "}");
            e.ChangedRange.SetFoldingMarkers(@"#region\b", @"#endregion\b");
        }

        [Obsolete]
        private void TextBoxEditor_Load(object sender, EventArgs e)
        {
            if (BoxEditor.Language == Language.CSharp)
            {
                CSharpCodeProvider codeProvider = new CSharpCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                OutputBox.Clear();
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);

                if (results.Errors.Count > 0)
                {                
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        if (string.IsNullOrEmpty(BoxEditor.Text))
                        {
                            OutputBox.Clear();
                            OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                            Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                            Errorbtn.Text = "";
                        }
                        
                    }
                }
                else if (results.Errors.Count == 0)
                {
                    OutputBox.Clear();
                    OutputBox.Text = "";
                    Errorbtn.Text = "";
                }
            }
            else if (BoxEditor.Language == Language.VB)
            {
                
                VBCodeProvider codeProvider = new VBCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                OutputBox.Clear();
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);

                if (results.Errors.Count > 0)
                {
                    OutputBox.Clear();
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        if (string.IsNullOrEmpty(BoxEditor.Text))
                        {
                            OutputBox.Clear();
                            OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                            Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                            Errorbtn.Text = "";
                        }
                    }
                }
                else if (results.Errors.Count == 0)
                {
                    OutputBox.Clear();
                    OutputBox.Text = "";
                    Errorbtn.Text = "";
                }
            }

            if (Properties.Settings.Default.Theme == 0)
            {
                BackColor = Color.White;
                label1.ForeColor = Color.Black;
                Errorbtn.ForeColor = Color.Black;
                PathLabel.ForeColor = Color.Black;
                toolStripStatusLabel1.ForeColor = Color.Black;
                toolStripStatusLabel2.ForeColor = Color.Black;
                toolStripStatusLabel3.ForeColor = Color.Black;
                toolStripStatusLabel4.ForeColor = Color.Black;
                toolStripStatusLabel5.ForeColor = Color.Black;
                toolStripStatusLabel6.ForeColor = Color.Black;
                documentMap1.BackColor = Color.White;
                statusStrip1.BackColor = Color.WhiteSmoke;
                statusStrip2.BackColor = Color.WhiteSmoke;
                OutputBox.BackColor = Color.White;
                OutputBox.ForeColor = Color.Black;
                guna2Panel7.FillColor = Color.Gainsboro;
                TopPanel.FillColor = Color.Gainsboro;
                guna2Panel6.FillColor = Color.WhiteSmoke;
                StartBtn.FillColor = Color.Silver;
                guna2Button2.FillColor = Color.Silver;
                guna2Button1.FillColor = Color.Silver;
                StartBtn.ForeColor = Color.ForestGreen;
                guna2Button2.ForeColor = Color.Black;
                guna2Button1.ForeColor = Color.Black;
                s.ForeColor = Color.Black;
                topToolStripMenuItem.BackColor = Color.WhiteSmoke;
                topToolStripMenuItem.ForeColor = Color.Black;
                leftToolStripMenuItem.BackColor = Color.WhiteSmoke;
                leftToolStripMenuItem.ForeColor = Color.Black;
                rightToolStripMenuItem.BackColor = Color.WhiteSmoke;
                rightToolStripMenuItem.ForeColor = Color.Black;
                bottomToolStripMenuItem.BackColor = Color.WhiteSmoke;
                bottomToolStripMenuItem.ForeColor = Color.Black;
                resetToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                resetToolStripMenuItem1.ForeColor = Color.Black;
                resetToolStripMenuItem.BackColor = Color.WhiteSmoke;
                resetToolStripMenuItem.ForeColor = Color.Black;
                leftToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                leftToolStripMenuItem1.ForeColor = Color.Black;
                rightToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                rightToolStripMenuItem1.ForeColor = Color.Black;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                BackColor = Color.DimGray;
                label1.ForeColor = Color.White;
                Errorbtn.ForeColor = Color.White;
                PathLabel.ForeColor = Color.White;
                toolStripStatusLabel1.ForeColor = Color.White;
                toolStripStatusLabel2.ForeColor = Color.White;
                toolStripStatusLabel3.ForeColor = Color.White;
                toolStripStatusLabel4.ForeColor = Color.White;
                toolStripStatusLabel5.ForeColor = Color.White;
                toolStripStatusLabel6.ForeColor = Color.White;
                documentMap1.BackColor = Color.Gray;
                statusStrip1.BackColor = Color.DimGray;
                statusStrip2.BackColor = Color.DimGray;
                OutputBox.BackColor = Color.FromArgb(70, 70, 70);
                OutputBox.ForeColor = Color.White;
                guna2Panel7.FillColor = Color.FromArgb(60, 60, 60);
                TopPanel.FillColor = Color.FromArgb(60, 60, 60);
                guna2Panel6.FillColor = Color.FromArgb(50, 50, 50);
                StartBtn.FillColor = Color.FromArgb(40, 40, 40);
                guna2Button2.FillColor = Color.FromArgb(40, 40, 40);
                guna2Button1.FillColor = Color.FromArgb(40, 40, 40);
                StartBtn.ForeColor = Color.LightGreen;
                guna2Button2.ForeColor = Color.White;
                guna2Button1.ForeColor = Color.White;
                s.ForeColor = Color.White;
                topToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                topToolStripMenuItem.ForeColor = Color.White;
                leftToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                leftToolStripMenuItem.ForeColor = Color.White;
                rightToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                rightToolStripMenuItem.ForeColor = Color.White;
                bottomToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                bottomToolStripMenuItem.ForeColor = Color.White;
                resetToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                resetToolStripMenuItem1.ForeColor = Color.White;
                resetToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                resetToolStripMenuItem.ForeColor = Color.White;
                leftToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                leftToolStripMenuItem1.ForeColor = Color.White;
                rightToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                rightToolStripMenuItem1.ForeColor = Color.White;
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            OutputBox.Clear();
            Errorbtn.Text = "";
        }

        [Obsolete]
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (BoxEditor.Language == Language.CSharp)
            {
                CSharpCodeProvider codeProvider = new CSharpCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);
                OutputBox.Clear();

                if (results.Errors.Count > 0)
                {
                    OutputBox.Clear();
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                        Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                    }
                }
                else if (results.Errors.Count == 0)
                {
                    OutputBox.Text = "";
                    Errorbtn.Text = "";
                }


            }
            else if (BoxEditor.Language == Language.VB)
            {
                VBCodeProvider codeProvider = new VBCodeProvider();
                ICodeCompiler icc = codeProvider.CreateCompiler();
                string path = PathLabel.Text;
                string Output = (path + "\\" + s.Text);
                CompilerParameters parameters = new CompilerParameters();
                parameters.GenerateExecutable = true;
                parameters.OutputAssembly = Output;
                parameters.ReferencedAssemblies.Add("System.dll");
                parameters.ReferencedAssemblies.Add("System.Core.dll");
                parameters.ReferencedAssemblies.Add("System.Data.dll");
                parameters.ReferencedAssemblies.Add("System.Data.Linq.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.dll");
                parameters.ReferencedAssemblies.Add("System.Design.dll");
                parameters.ReferencedAssemblies.Add("System.IO.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Log.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.dll");
                parameters.ReferencedAssemblies.Add("System.IO.Compression.FileSystem.dll");
                parameters.ReferencedAssemblies.Add("System.Web.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.dll");
                parameters.ReferencedAssemblies.Add("System.Windows.Forms.dll");
                parameters.ReferencedAssemblies.Add("System.Security.dll");
                parameters.ReferencedAssemblies.Add("System.Net.dll");
                parameters.ReferencedAssemblies.Add("System.Numerics.dll");
                parameters.ReferencedAssemblies.Add("System.Device.dll");
                parameters.ReferencedAssemblies.Add("System.Configuration.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.CSharp.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.JScript.dll");
                parameters.ReferencedAssemblies.Add("Microsoft.VisualC.dll");
                parameters.ReferencedAssemblies.Add("System.Management.dll");
                parameters.ReferencedAssemblies.Add("System.Drawing.Design.dll");
                parameters.ReferencedAssemblies.Add("System.Deployment.dll");
                CompilerResults results = icc.CompileAssemblyFromSource(parameters, BoxEditor.Text);
                OutputBox.Clear();

                if (results.Errors.Count > 0)
                {
                    OutputBox.Clear();
                    OutputBox.ForeColor = Color.Red;
                    foreach (CompilerError CompErr in results.Errors)
                    {
                        OutputBox.AppendText($"Error - Description: \"{CompErr.ErrorText}\"" + " | " + "Line " + CompErr.Line + " | " + "Error Number: " + CompErr.ErrorNumber + ";" + Environment.NewLine);
                        Errorbtn.Text = results.Errors.Count.ToString() + MyStrings._10title;
                    }
                }
                else if (results.Errors.Count == 0)
                {
                    OutputBox.Text = "";
                    Errorbtn.Text = "";
                }


            }            
        }

        private void rightToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            documentMap1.Dock = DockStyle.Right;
            splitter1.Dock = DockStyle.Right;
            Properties.Settings.Default.MapDock = documentMap1.Dock;
            Properties.Settings.Default.MapDock =splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void leftToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            documentMap1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            Properties.Settings.Default.MapDock = documentMap1.Dock;
            Properties.Settings.Default.MapDock = splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            Properties.Settings.Default.MapSize = (Size)(Point)documentMap1.Size;
            Properties.Settings.Default.Save();
        }

        private void splitter3_SplitterMoved(object sender, SplitterEventArgs e)
        {
            Properties.Settings.Default.OutSize = (Size)(Point)guna2Panel6.Size;
            Properties.Settings.Default.Save();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            splitter1.Dock = DockStyle.Right;
            documentMap1.Dock = DockStyle.Right;
            documentMap1.Size = new Size(100, 354);
            Properties.Settings.Default.MapDock = documentMap1.Dock;
            Properties.Settings.Default.MapDock = splitter1.Dock;
            Properties.Settings.Default.MapSize = (Size)(Point)documentMap1.Size;
            Properties.Settings.Default.Save();
        }

        private void resetToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            splitter3.Dock = DockStyle.Bottom;
            guna2Panel6.Dock = DockStyle.Bottom;
            guna2Panel6.Size = new Size(606, 141);
            splitter3.Cursor = Cursors.SizeNS;
            Properties.Settings.Default.OutCursor = splitter3.Cursor;
            Properties.Settings.Default.OutSize = (Size)(Point)guna2Panel6.Size;
            Properties.Settings.Default.OutDock = guna2Panel6.Dock;
            Properties.Settings.Default.OutDock = splitter3.Dock;
            Properties.Settings.Default.Save();
        }

        private void BoxEditor_ZoomChanged(object sender, EventArgs e)
        {

        }
    }

    internal class DynamicCollection : IEnumerable<AutocompleteMenuNS.AutocompleteItem>
    {
        private AutocompleteMenuNS.AutocompleteMenu menu;
        private FastColoredTextBox tb;

        public DynamicCollection(AutocompleteMenuNS.AutocompleteMenu menu, FastColoredTextBox tb)
        {
            this.menu = menu;
            this.tb = tb;
        }

        public IEnumerator<AutocompleteMenuNS.AutocompleteItem> GetEnumerator()
        {
            //get current fragment of the text
            var text = menu.Fragment.Text;


            //extract class name (part before dot)
            var parts = text.Split('.');
            if (parts.Length < 2)
                yield break;
            var className = parts[parts.Length - 2];

            //find type for given className
            var type = FindTypeByName(className);

            if (type == null)
                yield break;

            //return static methods of the class
            foreach (var methodName in type.GetMethods().AsEnumerable().Select(mi => mi.Name).Distinct())
                yield return new AutocompleteMenuNS.MethodAutocompleteItem(methodName + "()");


            //return static properties of the class
            foreach (var pi in type.GetProperties())
                yield return new AutocompleteMenuNS.MethodAutocompleteItem(pi.Name);

        }

        Type FindTypeByName(string name)
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            foreach (var a in assemblies)
            {
                foreach (var t in a.GetTypes())
                    if (t.Name == name)
                    {
                        return t;
                    }
            }

            return null;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
