﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace Qensy_Studio
{
    public partial class Create : Form
    {
        public bool createbtn = false;

        [Obsolete]
        public Create()
        {
            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }

            InitializeComponent();

            if(guna2ComboBox1.SelectedIndex == 0)
            {
                guna2TextBox1.Text = "ConsoleApp";
            }
            else if (guna2ComboBox1.SelectedIndex == 1)
            {
                guna2TextBox1.Text = "WebSite";
            }

            string mainPath = Environment.UserName;
            guna2TextBox2.Text = $"C:\\Users\\{mainPath}\\Desktop";
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (OpenPath.ShowDialog() == DialogResult.Cancel)
                return;
            string Path = OpenPath.SelectedPath;
            guna2TextBox2.Text = Path;
        }

        private void Create_Load(object sender, EventArgs e)
        {
            guna2Button1.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button1.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button1.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button2.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button2.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button2.BorderRadius = Properties.Settings.Default.butradius;

            guna2Button3.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button3.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button3.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button3.BorderRadius = Properties.Settings.Default.butradius;

            guna2ComboBox1.FillColor = Properties.Settings.Default.fillcolor;
            guna2ComboBox1.ForeColor = Properties.Settings.Default.forecolor;
            guna2ComboBox1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2ComboBox1.BorderRadius = Properties.Settings.Default.butradius;

            guna2ComboBox2.FillColor = Properties.Settings.Default.fillcolor;
            guna2ComboBox2.ForeColor = Properties.Settings.Default.forecolor;
            guna2ComboBox2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2ComboBox2.BorderRadius = Properties.Settings.Default.butradius;

            guna2TextBox1.FillColor = Properties.Settings.Default.fillcolor;
            guna2TextBox1.ForeColor = Properties.Settings.Default.forecolor;
            guna2TextBox1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2TextBox1.BorderRadius = Properties.Settings.Default.butradius;

            guna2TextBox2.Enabled = true;
            guna2TextBox2.FillColor = Properties.Settings.Default.fillcolor;
            guna2TextBox2.ForeColor = Properties.Settings.Default.forecolor;
            guna2TextBox2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2TextBox2.BorderRadius = Properties.Settings.Default.butradius;
            guna2TextBox2.Enabled = false;

            if (Properties.Settings.Default.Theme == 0)
            {
                BackColor = Color.White;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                BackColor = Color.DimGray;
            }
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (guna2ComboBox1.SelectedIndex == 0)
            {
                guna2TextBox1.Text = "ConsoleApp";
                guna2ComboBox2.Items.Clear();
                guna2ComboBox2.Items.Add("C#");
                guna2ComboBox2.Items.Add("VisualBasic");
                guna2ComboBox2.SelectedIndex = 0;
                guna2ComboBox2.Visible = true;
            }
            else if (guna2ComboBox1.SelectedIndex == 1)
            {
                guna2TextBox1.Text = "WebSite";
                guna2ComboBox2.Items.Clear();
                guna2ComboBox2.Items.Add("HTML");
                guna2ComboBox2.SelectedIndex = 0;
                guna2ComboBox2.Visible = true;
            }
            else if (guna2ComboBox1.SelectedIndex == 2)
            {
                guna2ComboBox2.Visible = false;
                guna2TextBox1.Text = "MyTextDocument";
            }
        }

        [Obsolete]
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            createbtn = true;

            string dirpath = guna2TextBox2.Text + "\\" + guna2TextBox1.Text;
            MainForm mainForm = new MainForm();
            DirectoryInfo directory = new DirectoryInfo(guna2TextBox2.Text + "\\" + guna2TextBox1.Text);
            string existtxt = dirpath + ".txt";
            if (!directory.Exists && guna2ComboBox1.SelectedIndex != 2)
            {
                directory.Create();              
                if (guna2ComboBox2.SelectedIndex == 0 && guna2ComboBox1.SelectedIndex == 0)
                {
                    using (StreamWriter fs = new StreamWriter(dirpath + "\\" + guna2TextBox1.Text + ".cs"))
                    {
                        fs.WriteLine("using System;\n\n" + $"namespace {guna2TextBox1.Text}\n" + "{\n" + "    class Program \n    {\n        static void Main(string[] args)\n        {\n            Console.WriteLine(\"Hello, World!\");\n            Console.ReadKey();\n        }\n    }\n}");
                    }
                    
                }
                else if (guna2ComboBox2.SelectedIndex == 1 && guna2ComboBox1.SelectedIndex == 0)
                {
                    using (StreamWriter fs = new StreamWriter(dirpath + "\\" + guna2TextBox1.Text + ".vb"))
                    {
                        fs.WriteLine("Imports System\n\n" + $"Module {guna2TextBox1.Text}\n" + "    Sub Main()\n        Console.WriteLine(\"Hello, World!\")\n        Console.ReadKey(true)\n    End Sub\nEnd Module");
                    }
                }
                else if (guna2ComboBox2.SelectedIndex == 0 && guna2ComboBox1.SelectedIndex == 1)
                {
                    using (StreamWriter fs = new StreamWriter(dirpath + "\\" + guna2TextBox1.Text + ".html"))
                    {                        
                        fs.WriteLine("<!DOCTYPE html>\n\n<html>\n    <head>\n" + $"        <title>{guna2TextBox1.Text}</title>\n" + "    </head>\n    <body>\n        <p>Hello, World!</p>\n    </body>\n</html>");
                    }
                }

                Close();

            }
            else if (guna2ComboBox1.SelectedIndex == 2)
            {
                using (StreamWriter fs = new StreamWriter(existtxt))
                {
                    fs.WriteLine("=================== " + $"{guna2TextBox1.Text}" + " ===================\n");
                }
                Close();

            }             
            else if(guna2TextBox1.Text == string.Empty)
            {
                MessageBox.Show(MyStrings._7text, MyStrings._7title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                createbtn = false;
            }
            else if (directory.Exists)
            {
                MessageBox.Show(MyStrings._8text, MyStrings._8title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                createbtn = false;
            }
        }
    }
}
