﻿
namespace Qensy_Studio
{
    partial class TextBoxEditor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Obsolete]
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextBoxEditor));
            this.TopPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.PathLabel = new System.Windows.Forms.Label();
            this.StartBtn = new Guna.UI2.WinForms.Guna2Button();
            this.documentMap1 = new FastColoredTextBoxNS.DocumentMap();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.rightToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BoxEditor = new FastColoredTextBoxNS.FastColoredTextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.OutputBox = new System.Windows.Forms.TextBox();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.topToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Errorbtn = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.s = new System.Windows.Forms.ToolStripStatusLabel();
            this.autocompleteMenu1 = new AutocompleteMenuNS.AutocompleteMenu();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.TopPanel.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BoxEditor)).BeginInit();
            this.guna2Panel6.SuspendLayout();
            this.guna2Panel7.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopPanel
            // 
            this.TopPanel.Controls.Add(this.PathLabel);
            this.TopPanel.Controls.Add(this.StartBtn);
            resources.ApplyResources(this.TopPanel, "TopPanel");
            this.TopPanel.FillColor = System.Drawing.Color.LightGray;
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.ShadowDecoration.Parent = this.TopPanel;
            // 
            // PathLabel
            // 
            resources.ApplyResources(this.PathLabel, "PathLabel");
            this.PathLabel.BackColor = System.Drawing.Color.Transparent;
            this.PathLabel.Name = "PathLabel";
            // 
            // StartBtn
            // 
            this.StartBtn.CheckedState.Parent = this.StartBtn;
            this.StartBtn.CustomImages.Parent = this.StartBtn;
            resources.ApplyResources(this.StartBtn, "StartBtn");
            this.StartBtn.FillColor = System.Drawing.Color.Silver;
            this.StartBtn.ForeColor = System.Drawing.Color.ForestGreen;
            this.StartBtn.HoverState.Parent = this.StartBtn;
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.ShadowDecoration.Parent = this.StartBtn;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // documentMap1
            // 
            this.documentMap1.BackColor = System.Drawing.Color.White;
            this.documentMap1.ContextMenuStrip = this.contextMenuStrip2;
            resources.ApplyResources(this.documentMap1, "documentMap1");
            this.documentMap1.ForeColor = System.Drawing.Color.Black;
            this.documentMap1.Name = "documentMap1";
            this.documentMap1.Scale = 0.5F;
            this.documentMap1.ScrollbarVisible = false;
            this.documentMap1.Target = this.BoxEditor;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rightToolStripMenuItem1,
            this.leftToolStripMenuItem1,
            this.resetToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            resources.ApplyResources(this.contextMenuStrip2, "contextMenuStrip2");
            // 
            // rightToolStripMenuItem1
            // 
            this.rightToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Menu;
            this.rightToolStripMenuItem1.Name = "rightToolStripMenuItem1";
            resources.ApplyResources(this.rightToolStripMenuItem1, "rightToolStripMenuItem1");
            this.rightToolStripMenuItem1.Click += new System.EventHandler(this.rightToolStripMenuItem1_Click);
            // 
            // leftToolStripMenuItem1
            // 
            this.leftToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Menu;
            this.leftToolStripMenuItem1.Name = "leftToolStripMenuItem1";
            resources.ApplyResources(this.leftToolStripMenuItem1, "leftToolStripMenuItem1");
            this.leftToolStripMenuItem1.Click += new System.EventHandler(this.leftToolStripMenuItem1_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            resources.ApplyResources(this.resetToolStripMenuItem, "resetToolStripMenuItem");
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // BoxEditor
            // 
            this.BoxEditor.AutoCompleteBrackets = true;
            this.BoxEditor.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.autocompleteMenu1.SetAutocompleteMenu(this.BoxEditor, this.autocompleteMenu1);
            this.BoxEditor.AutoIndentChars = false;
            this.BoxEditor.AutoIndentCharsPatterns = "^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\r\n^\\s*(case|default)\\s*[^:]*" +
    "(?<range>:)\\s*(?<range>[^;]+);";
            resources.ApplyResources(this.BoxEditor, "BoxEditor");
            this.BoxEditor.BackBrush = null;
            this.BoxEditor.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.BoxEditor.CharHeight = 15;
            this.BoxEditor.CharWidth = 7;
            this.BoxEditor.CurrentLineColor = System.Drawing.Color.LightGray;
            this.BoxEditor.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.BoxEditor.DescriptionFile = "";
            this.BoxEditor.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.BoxEditor.ForeColor = System.Drawing.Color.Black;
            this.BoxEditor.IsReplaceMode = false;
            this.BoxEditor.LineNumberColor = System.Drawing.Color.Black;
            this.BoxEditor.Name = "BoxEditor";
            this.BoxEditor.Paddings = new System.Windows.Forms.Padding(0);
            this.BoxEditor.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BoxEditor.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("BoxEditor.ServiceColors")));
            this.BoxEditor.ServiceLinesColor = System.Drawing.Color.Black;
            this.BoxEditor.WordWrap = true;
            this.BoxEditor.WordWrapIndent = 1;
            this.BoxEditor.WordWrapMode = FastColoredTextBoxNS.WordWrapMode.Custom;
            this.BoxEditor.Zoom = 100;
            this.BoxEditor.TextChanged += new System.EventHandler<FastColoredTextBoxNS.TextChangedEventArgs>(this.BoxEditor_TextChanged);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.splitter1.Cursor = System.Windows.Forms.Cursors.SizeWE;
            resources.ApplyResources(this.splitter1, "splitter1");
            this.splitter1.Name = "splitter1";
            this.splitter1.TabStop = false;
            this.splitter1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter1_SplitterMoved);
            // 
            // splitter3
            // 
            this.splitter3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.splitter3.Cursor = System.Windows.Forms.Cursors.SizeNS;
            resources.ApplyResources(this.splitter3, "splitter3");
            this.splitter3.Name = "splitter3";
            this.splitter3.TabStop = false;
            this.splitter3.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter3_SplitterMoved);
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel6.Controls.Add(this.guna2Button2);
            this.guna2Panel6.Controls.Add(this.OutputBox);
            this.guna2Panel6.Controls.Add(this.guna2Panel7);
            resources.ApplyResources(this.guna2Panel6, "guna2Panel6");
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            // 
            // guna2Button2
            // 
            resources.ApplyResources(this.guna2Button2, "guna2Button2");
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.Silver;
            this.guna2Button2.ForeColor = System.Drawing.Color.Black;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // OutputBox
            // 
            resources.ApplyResources(this.OutputBox, "OutputBox");
            this.autocompleteMenu1.SetAutocompleteMenu(this.OutputBox, null);
            this.OutputBox.BackColor = System.Drawing.Color.White;
            this.OutputBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OutputBox.Name = "OutputBox";
            this.OutputBox.ReadOnly = true;
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel7.ContextMenuStrip = this.contextMenuStrip1;
            this.guna2Panel7.Controls.Add(this.Errorbtn);
            this.guna2Panel7.Controls.Add(this.guna2Button1);
            this.guna2Panel7.Controls.Add(this.label1);
            resources.ApplyResources(this.guna2Panel7, "guna2Panel7");
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topToolStripMenuItem,
            this.leftToolStripMenuItem,
            this.rightToolStripMenuItem,
            this.bottomToolStripMenuItem,
            this.resetToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // topToolStripMenuItem
            // 
            this.topToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.topToolStripMenuItem.Name = "topToolStripMenuItem";
            resources.ApplyResources(this.topToolStripMenuItem, "topToolStripMenuItem");
            this.topToolStripMenuItem.Click += new System.EventHandler(this.topToolStripMenuItem_Click);
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            resources.ApplyResources(this.leftToolStripMenuItem, "leftToolStripMenuItem");
            this.leftToolStripMenuItem.Click += new System.EventHandler(this.leftToolStripMenuItem_Click);
            // 
            // rightToolStripMenuItem
            // 
            this.rightToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.rightToolStripMenuItem.Name = "rightToolStripMenuItem";
            resources.ApplyResources(this.rightToolStripMenuItem, "rightToolStripMenuItem");
            this.rightToolStripMenuItem.Click += new System.EventHandler(this.rightToolStripMenuItem_Click);
            // 
            // bottomToolStripMenuItem
            // 
            this.bottomToolStripMenuItem.BackColor = System.Drawing.SystemColors.Menu;
            this.bottomToolStripMenuItem.Name = "bottomToolStripMenuItem";
            resources.ApplyResources(this.bottomToolStripMenuItem, "bottomToolStripMenuItem");
            this.bottomToolStripMenuItem.Click += new System.EventHandler(this.bottomToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem1
            // 
            this.resetToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Menu;
            this.resetToolStripMenuItem1.Name = "resetToolStripMenuItem1";
            resources.ApplyResources(this.resetToolStripMenuItem1, "resetToolStripMenuItem1");
            this.resetToolStripMenuItem1.Click += new System.EventHandler(this.resetToolStripMenuItem1_Click);
            // 
            // Errorbtn
            // 
            resources.ApplyResources(this.Errorbtn, "Errorbtn");
            this.Errorbtn.BackColor = System.Drawing.Color.Transparent;
            this.Errorbtn.Name = "Errorbtn";
            // 
            // guna2Button1
            // 
            resources.ApplyResources(this.guna2Button1, "guna2Button1");
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Silver;
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel7,
            this.s});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.SizingGrip = false;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            resources.ApplyResources(this.toolStripStatusLabel2, "toolStripStatusLabel2");
            this.toolStripStatusLabel2.Click += new System.EventHandler(this.toolStripStatusLabel2_Click);
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            resources.ApplyResources(this.toolStripStatusLabel7, "toolStripStatusLabel7");
            // 
            // s
            // 
            this.s.Name = "s";
            resources.ApplyResources(this.s, "s");
            // 
            // autocompleteMenu1
            // 
            this.autocompleteMenu1.AllowsTabKey = true;
            this.autocompleteMenu1.AppearInterval = 10;
            this.autocompleteMenu1.Colors = ((AutocompleteMenuNS.Colors)(resources.GetObject("autocompleteMenu1.Colors")));
            this.autocompleteMenu1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.autocompleteMenu1.ImageList = null;
            this.autocompleteMenu1.Items = new string[0];
            this.autocompleteMenu1.LeftPadding = 0;
            this.autocompleteMenu1.MinFragmentLength = 1;
            this.autocompleteMenu1.TargetControlWrapper = null;
            // 
            // statusStrip2
            // 
            this.statusStrip2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6});
            resources.ApplyResources(this.statusStrip2, "statusStrip2");
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.SizingGrip = false;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            resources.ApplyResources(this.toolStripStatusLabel3, "toolStripStatusLabel3");
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            resources.ApplyResources(this.toolStripStatusLabel4, "toolStripStatusLabel4");
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            resources.ApplyResources(this.toolStripStatusLabel5, "toolStripStatusLabel5");
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            resources.ApplyResources(this.toolStripStatusLabel6, "toolStripStatusLabel6");
            // 
            // TextBoxEditor
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.BoxEditor);
            this.Controls.Add(this.statusStrip2);
            this.Controls.Add(this.TopPanel);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.guna2Panel6);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.documentMap1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "TextBoxEditor";
            this.Load += new System.EventHandler(this.TextBoxEditor_Load);
            this.TopPanel.ResumeLayout(false);
            this.TopPanel.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BoxEditor)).EndInit();
            this.guna2Panel6.ResumeLayout(false);
            this.guna2Panel6.PerformLayout();
            this.guna2Panel7.ResumeLayout(false);
            this.guna2Panel7.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label PathLabel;
        public Guna.UI2.WinForms.Guna2Panel TopPanel;
        public Guna.UI2.WinForms.Guna2Button StartBtn;
        private System.Windows.Forms.Splitter splitter1;
        public System.Windows.Forms.TextBox OutputBox;
        public System.Windows.Forms.Splitter splitter3;
        public Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        public Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomToolStripMenuItem;
        public System.Windows.Forms.StatusStrip statusStrip1;
        public System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        public System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        public FastColoredTextBoxNS.DocumentMap documentMap1;
        private System.Windows.Forms.Label label1;
        public FastColoredTextBoxNS.FastColoredTextBox BoxEditor;
        public AutocompleteMenuNS.AutocompleteMenu autocompleteMenu1;
        public System.Windows.Forms.Label Errorbtn;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        public System.Windows.Forms.ToolStripStatusLabel s;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
    }
}
