﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Threading;
using Manina.Windows.Forms;


namespace Qensy_Studio
{
    public partial class MainForm : Form
    {
        [Obsolete]
        public MainForm()
        {
            
            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                
                Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }
            InitializeComponent();
            
            this.MinimumSize = new Size(700, 400);
            Create create = new Create();
            guna2PictureBox1.ImageLocation = Properties.Settings.Default.Picture;
            guna2Panel1.Size = (Size)Properties.Settings.Default.Splitter;
            guna2Panel1.Dock = Properties.Settings.Default.PanelDock;
            splitter1.Dock = Properties.Settings.Default.PanelDock;
            tabControl1.TabLocation = Properties.Settings.Default.tab;
            Properties.Settings.Default.Save();              
        }

        [Obsolete]
        private void MainMenu_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Theme == 0)
            {
                BackColor = Color.White;
                guna2Panel1.FillColor = Color.White;
                guna2PictureBox1.BackColor = Color.LightGray;
                splitter1.BackColor = Color.DimGray;
                menuStrip1.BackColor = Color.WhiteSmoke;
                fileToolStripMenuItem.ForeColor = Color.Black;
                editToolStripMenuItem.ForeColor = Color.Black;
                viewToolStripMenuItem.ForeColor = Color.Black;
                runToolStripMenuItem.ForeColor = Color.Black;
                projectToolStripMenuItem.ForeColor = Color.Black;
                hotKeysToolStripMenuItem.ForeColor = Color.Black;
                settingsToolStripMenuItem.ForeColor = Color.Black;
                documentationToolStripMenuItem.ForeColor = Color.Black;
                toMakeYourWorkEasieToolStripMenuItem.ForeColor = Color.Black;
                aboutToolStripMenuItem.ForeColor = Color.Black;
                tabControl1.BackColor = Color.White;
                //========Menus
                createToolStripMenuItem.ForeColor = Color.Black;
                createToolStripMenuItem.BackColor = Color.WhiteSmoke;
                openToolStripMenuItem.ForeColor = Color.Black;
                openToolStripMenuItem.BackColor = Color.WhiteSmoke;
                saveToolStripMenuItem.ForeColor = Color.Black;
                saveToolStripMenuItem.BackColor = Color.WhiteSmoke;
                saveAllToolStripMenuItem.ForeColor = Color.Black;
                saveAllToolStripMenuItem.BackColor = Color.WhiteSmoke;
                printPreviewToolStripMenuItem.ForeColor = Color.Black;
                printPreviewToolStripMenuItem.BackColor = Color.WhiteSmoke;
                exitToolStripMenuItem.ForeColor = Color.Black;
                exitToolStripMenuItem.BackColor = Color.WhiteSmoke;
                cutToolStripMenuItem.ForeColor = Color.Black;
                cutToolStripMenuItem.BackColor = Color.WhiteSmoke;
                copyToolStripMenuItem.ForeColor = Color.Black;
                copyToolStripMenuItem.BackColor = Color.WhiteSmoke;
                pasteToolStripMenuItem.ForeColor = Color.Black;
                pasteToolStripMenuItem.BackColor = Color.WhiteSmoke;
                undoToolStripMenuItem.ForeColor = Color.Black;
                undoToolStripMenuItem.BackColor = Color.WhiteSmoke;
                redoToolStripMenuItem.ForeColor = Color.Black;
                redoToolStripMenuItem.BackColor = Color.WhiteSmoke;
                selectAllToolStripMenuItem.ForeColor = Color.Black;
                selectAllToolStripMenuItem.BackColor = Color.WhiteSmoke;
                googleToolStripMenuItem.ForeColor = Color.Black;
                googleToolStripMenuItem.BackColor = Color.WhiteSmoke;
                googleTranslateToolStripMenuItem.ForeColor = Color.Black;
                googleTranslateToolStripMenuItem.BackColor = Color.WhiteSmoke;
                windowsExplorerToolStripMenuItem.ForeColor = Color.Black;
                windowsExplorerToolStripMenuItem.BackColor = Color.WhiteSmoke;
                settingsToolStripMenuItem1.ForeColor = Color.Black;
                settingsToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                restartToolStripMenuItem.ForeColor = Color.Black;
                restartToolStripMenuItem.BackColor = Color.WhiteSmoke;
                runConsoleToolStripMenuItem.ForeColor = Color.Black;
                runConsoleToolStripMenuItem.BackColor = Color.WhiteSmoke;
                buildToolStripMenuItem.ForeColor = Color.Black;
                buildToolStripMenuItem.BackColor = Color.WhiteSmoke;
                buildToolStripMenuItem1.ForeColor = Color.Black;
                buildToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                zipBuildToolStripMenuItem.ForeColor = Color.Black;
                zipBuildToolStripMenuItem.BackColor = Color.WhiteSmoke;
                menuPictureToolStripMenuItem.ForeColor = Color.Black;
                menuPictureToolStripMenuItem.BackColor = Color.WhiteSmoke;
                menuPanelToolStripMenuItem.ForeColor = Color.Black;
                menuPanelToolStripMenuItem.BackColor = Color.WhiteSmoke;
                resetAllToolStripMenuItem.ForeColor = Color.Black;
                resetAllToolStripMenuItem.BackColor = Color.WhiteSmoke;
                openPictureToolStripMenuItem.ForeColor = Color.Black;
                openPictureToolStripMenuItem.BackColor = Color.WhiteSmoke;
                clearPictureToolStripMenuItem.ForeColor = Color.Black;
                clearPictureToolStripMenuItem.BackColor = Color.WhiteSmoke;
                rightToolStripMenuItem.ForeColor = Color.Black;
                rightToolStripMenuItem.BackColor = Color.WhiteSmoke;
                leftToolStripMenuItem.ForeColor = Color.Black;
                leftToolStripMenuItem.BackColor = Color.WhiteSmoke;
                resetToolStripMenuItem.ForeColor = Color.Black;
                resetToolStripMenuItem.BackColor = Color.WhiteSmoke;
                tabToolStripMenuItem.BackColor = Color.WhiteSmoke;
                tabToolStripMenuItem.ForeColor = Color.Black;
                topLeftToolStripMenuItem.BackColor = Color.WhiteSmoke;
                topLeftToolStripMenuItem.ForeColor = Color.Black;
                topCenterToolStripMenuItem.BackColor = Color.WhiteSmoke;
                topCenterToolStripMenuItem.ForeColor = Color.Black;
                topRightToolStripMenuItem.BackColor = Color.WhiteSmoke;
                topRightToolStripMenuItem.ForeColor = Color.Black;
                rightTopToolStripMenuItem.BackColor = Color.WhiteSmoke;
                rightTopToolStripMenuItem.ForeColor = Color.Black;
                rightCenterToolStripMenuItem.BackColor = Color.WhiteSmoke;
                rightCenterToolStripMenuItem.ForeColor = Color.Black;
                rightBottomToolStripMenuItem.BackColor = Color.WhiteSmoke;
                rightBottomToolStripMenuItem.ForeColor = Color.Black;
                bottomRightToolStripMenuItem.BackColor = Color.WhiteSmoke;
                bottomRightToolStripMenuItem.ForeColor = Color.Black;
                bottomCenterToolStripMenuItem.BackColor = Color.WhiteSmoke;
                bottomCenterToolStripMenuItem.ForeColor = Color.Black;
                bottomLeftToolStripMenuItem.BackColor = Color.WhiteSmoke;
                bottomLeftToolStripMenuItem.ForeColor = Color.Black;
                leftBottomToolStripMenuItem.BackColor = Color.WhiteSmoke;
                leftBottomToolStripMenuItem.ForeColor = Color.Black;
                leftCenterToolStripMenuItem.BackColor = Color.WhiteSmoke;
                leftCenterToolStripMenuItem.ForeColor = Color.Black;
                leftTopToolStripMenuItem.BackColor = Color.WhiteSmoke;
                leftTopToolStripMenuItem.ForeColor = Color.Black;
                openInExplorerToolStripMenuItem.BackColor = Color.WhiteSmoke;
                openInExplorerToolStripMenuItem.ForeColor = Color.Black;
                //========ContextMenus
                saveToolStripMenuItem1.ForeColor = Color.Black;
                saveToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                saveAllToolStripMenuItem1.ForeColor = Color.Black;
                saveAllToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                closeToolStripMenuItem.ForeColor = Color.Black;
                closeToolStripMenuItem.BackColor = Color.WhiteSmoke;
                closeAllToolStripMenuItem.ForeColor = Color.Black;
                closeAllToolStripMenuItem.BackColor = Color.WhiteSmoke;
                copyPathToolStripMenuItem.ForeColor = Color.Black;
                copyPathToolStripMenuItem.BackColor = Color.WhiteSmoke;
                toolStripMenuItem1.ForeColor = Color.Black;
                toolStripMenuItem1.BackColor = Color.WhiteSmoke;
                toolStripMenuItem2.ForeColor = Color.Black;
                toolStripMenuItem2.BackColor = Color.WhiteSmoke;
                toolStripMenuItem3.ForeColor = Color.Black;
                toolStripMenuItem3.BackColor = Color.WhiteSmoke;
                toolStripMenuItem4.ForeColor = Color.Black;
                toolStripMenuItem4.BackColor = Color.WhiteSmoke;
                toolStripMenuItem5.ForeColor = Color.Black;
                toolStripMenuItem5.BackColor = Color.WhiteSmoke;
                toolStripMenuItem6.ForeColor = Color.Black;
                toolStripMenuItem6.BackColor = Color.WhiteSmoke;
                rightToolStripMenuItem2.ForeColor = Color.Black;
                rightToolStripMenuItem2.BackColor = Color.WhiteSmoke;
                leftToolStripMenuItem2.ForeColor = Color.Black;
                leftToolStripMenuItem2.BackColor = Color.WhiteSmoke;
                resetToolStripMenuItem1.ForeColor = Color.Black;
                resetToolStripMenuItem1.BackColor = Color.WhiteSmoke;
                toolStripMenuItem7.ForeColor = Color.Black;
                toolStripMenuItem7.BackColor = Color.WhiteSmoke;
                toolStripMenuItem9.ForeColor = Color.Black;
                toolStripMenuItem9.BackColor = Color.WhiteSmoke;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                BackColor = Color.DimGray;
                tabControl1.BackColor = Color.DimGray;
                guna2Panel1.FillColor = Color.DimGray;
                guna2PictureBox1.BackColor = Color.FromArgb(65, 65, 65);
                splitter1.BackColor = Color.DarkGray;
                menuStrip1.BackColor = Color.FromArgb(70, 70, 70);
                fileToolStripMenuItem.ForeColor = Color.White;
                editToolStripMenuItem.ForeColor = Color.White;
                viewToolStripMenuItem.ForeColor = Color.White;
                runToolStripMenuItem.ForeColor = Color.White;
                projectToolStripMenuItem.ForeColor = Color.White;
                hotKeysToolStripMenuItem.ForeColor = Color.White;
                settingsToolStripMenuItem.ForeColor = Color.White;
                documentationToolStripMenuItem.ForeColor = Color.White;
                toMakeYourWorkEasieToolStripMenuItem.ForeColor = Color.White;
                aboutToolStripMenuItem.ForeColor = Color.White;
                //========Menus
                createToolStripMenuItem.ForeColor = Color.White;
                createToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                openToolStripMenuItem.ForeColor = Color.White;
                openToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                saveToolStripMenuItem.ForeColor = Color.White;
                saveToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                saveAllToolStripMenuItem.ForeColor = Color.White;
                saveAllToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                printPreviewToolStripMenuItem.ForeColor = Color.White;
                printPreviewToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                exitToolStripMenuItem.ForeColor = Color.White;
                exitToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                cutToolStripMenuItem.ForeColor = Color.White;
                cutToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                copyToolStripMenuItem.ForeColor = Color.White;
                copyToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                pasteToolStripMenuItem.ForeColor = Color.White;
                pasteToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                undoToolStripMenuItem.ForeColor = Color.White;
                undoToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                redoToolStripMenuItem.ForeColor = Color.White;
                redoToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                selectAllToolStripMenuItem.ForeColor = Color.White;
                selectAllToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                googleToolStripMenuItem.ForeColor = Color.White;
                googleToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                googleTranslateToolStripMenuItem.ForeColor = Color.White;
                googleTranslateToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                windowsExplorerToolStripMenuItem.ForeColor = Color.White;
                windowsExplorerToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                settingsToolStripMenuItem1.ForeColor = Color.White;
                settingsToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                restartToolStripMenuItem.ForeColor = Color.White;
                restartToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                runConsoleToolStripMenuItem.ForeColor = Color.White;
                runConsoleToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                buildToolStripMenuItem.ForeColor = Color.White;
                buildToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                buildToolStripMenuItem1.ForeColor = Color.White;
                buildToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                zipBuildToolStripMenuItem.ForeColor = Color.White;
                zipBuildToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                menuPictureToolStripMenuItem.ForeColor = Color.White;
                menuPictureToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                menuPanelToolStripMenuItem.ForeColor = Color.White;
                menuPanelToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                resetAllToolStripMenuItem.ForeColor = Color.White;
                resetAllToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                openPictureToolStripMenuItem.ForeColor = Color.White;
                openPictureToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                clearPictureToolStripMenuItem.ForeColor = Color.White;
                clearPictureToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                rightToolStripMenuItem.ForeColor = Color.White;
                rightToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                leftToolStripMenuItem.ForeColor = Color.White;
                leftToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                resetToolStripMenuItem.ForeColor = Color.White;
                resetToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                tabToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                tabToolStripMenuItem.ForeColor = Color.White;
                topLeftToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                topLeftToolStripMenuItem.ForeColor = Color.White;
                topCenterToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                topCenterToolStripMenuItem.ForeColor = Color.White;
                topRightToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                topRightToolStripMenuItem.ForeColor = Color.White;
                rightTopToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                rightTopToolStripMenuItem.ForeColor = Color.White;
                rightCenterToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                rightCenterToolStripMenuItem.ForeColor = Color.White;
                rightBottomToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                rightBottomToolStripMenuItem.ForeColor = Color.White;
                bottomRightToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                bottomRightToolStripMenuItem.ForeColor = Color.White;
                bottomCenterToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                bottomCenterToolStripMenuItem.ForeColor = Color.White;
                bottomLeftToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                bottomLeftToolStripMenuItem.ForeColor = Color.White;
                leftBottomToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                leftBottomToolStripMenuItem.ForeColor = Color.White;
                leftCenterToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                leftCenterToolStripMenuItem.ForeColor = Color.White;
                leftTopToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                leftTopToolStripMenuItem.ForeColor = Color.White;
                openInExplorerToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                openInExplorerToolStripMenuItem.ForeColor = Color.White;
                //========ContextMenus
                saveToolStripMenuItem1.ForeColor = Color.White;
                saveToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                saveAllToolStripMenuItem1.ForeColor = Color.White;
                saveAllToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                closeToolStripMenuItem.ForeColor = Color.White;
                closeToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                closeAllToolStripMenuItem.ForeColor = Color.White;
                closeAllToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                copyPathToolStripMenuItem.ForeColor = Color.White;
                copyPathToolStripMenuItem.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem1.ForeColor = Color.White;
                toolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem2.ForeColor = Color.White;
                toolStripMenuItem2.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem3.ForeColor = Color.White;
                toolStripMenuItem3.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem4.ForeColor = Color.White;
                toolStripMenuItem4.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem5.ForeColor = Color.White;
                toolStripMenuItem5.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem6.ForeColor = Color.White;
                toolStripMenuItem6.BackColor = Color.FromArgb(70, 70, 70);
                rightToolStripMenuItem2.ForeColor = Color.White;
                rightToolStripMenuItem2.BackColor = Color.FromArgb(70, 70, 70);
                leftToolStripMenuItem2.ForeColor = Color.White;
                leftToolStripMenuItem2.BackColor = Color.FromArgb(70, 70, 70);
                resetToolStripMenuItem1.ForeColor = Color.White;
                resetToolStripMenuItem1.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem7.ForeColor = Color.White;
                toolStripMenuItem7.BackColor = Color.FromArgb(70, 70, 70);
                toolStripMenuItem9.ForeColor = Color.White;
                toolStripMenuItem9.BackColor = Color.FromArgb(70, 70, 70);
            }

            if (Editor.Visible == false)
            {
                editToolStripMenuItem.Visible = false;
                runToolStripMenuItem.Visible = false;
                saveAllToolStripMenuItem.Visible = false;
                saveToolStripMenuItem.Visible = false;
                printPreviewToolStripMenuItem.Visible = false;
                hotKeysToolStripMenuItem.Visible = false;
                projectToolStripMenuItem.Visible = false;
            }
            if (Editor.Visible == true)
            {
                editToolStripMenuItem.Visible = true;
                runToolStripMenuItem.Visible = true;
                saveAllToolStripMenuItem.Visible = true;
                saveToolStripMenuItem.Visible = true;
                printPreviewToolStripMenuItem.Visible = true;
                hotKeysToolStripMenuItem.Visible = true;
                projectToolStripMenuItem.Visible = true;
            }
            guna2Button1.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button1.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button1.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button1.BorderRadius = Properties.Settings.Default.butradius;
            guna2Button2.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button2.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button2.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button2.BorderRadius = Properties.Settings.Default.butradius;
            guna2Button3.FillColor = Properties.Settings.Default.fillcolor;
            guna2Button3.ForeColor = Properties.Settings.Default.forecolor;
            guna2Button3.BorderColor = Properties.Settings.Default.bordercolor;
            guna2Button3.BorderRadius = Properties.Settings.Default.butradius;          
        }           

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

        private void leftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            splitter1.Cursor = Cursors.SizeWE;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void rightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel1.Dock = DockStyle.Right;
            splitter1.Dock = DockStyle.Right;
            splitter1.Cursor = Cursors.SizeWE;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void bottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel1.Dock = DockStyle.Bottom;
            splitter1.Dock = DockStyle.Bottom;
            splitter1.Cursor = Cursors.SizeNS;
        }

        private void openPictureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (OpenPicture.ShowDialog() == DialogResult.Cancel)
                return;
            string path = OpenPicture.FileName;
            guna2PictureBox1.ImageLocation = path;
            Properties.Settings.Default.Picture = guna2PictureBox1.ImageLocation;
            Properties.Settings.Default.Save();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Panel1.Size = new Size(180, 336);
            guna2Panel1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Splitter = guna2Panel1.Size;
            Properties.Settings.Default.Save();            
        }

        private void clearPictureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2PictureBox1.ImageLocation = null;
            Properties.Settings.Default.Picture = guna2PictureBox1.ImageLocation;
            Properties.Settings.Default.Save();
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            Properties.Settings.Default.Splitter = (Size)(Point)guna2Panel1.Size;
            Properties.Settings.Default.Save();
        }

        private void MainMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void resetAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2PictureBox1.ImageLocation = null;
            guna2Panel1.Size = new Size(180, 336);
            guna2Panel1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Splitter = guna2Panel1.Size;            
            Properties.Settings.Default.Picture = guna2PictureBox1.ImageLocation;
            Properties.Settings.Default.Save();
        }

        [Obsolete]
        public void guna2Button1_Click(object sender, EventArgs e)
        {
            Create create = new Create();
            create.ShowDialog();
            var tabPage = new Tab();
            if (Properties.Settings.Default.Theme == 0)
            {
                tabPage.BackColor = Color.White;
                tabPage.ForeColor = Color.Black;
            }
            else if (Properties.Settings.Default.Theme == 1)
            {
                tabPage.BackColor = Color.Gray;
                tabPage.ForeColor = Color.White;
            }
            if (create.createbtn == true)
            {
                if (create.guna2ComboBox2.SelectedIndex == 0 && create.guna2ComboBox1.SelectedIndex == 0)
                {
                    MainPanel.Visible = false;
                    Editor.Visible = true;                   
                    var TextEditor = new TextBoxEditor();

                    TextEditor.BoxEditor.ContextMenuStrip = contextMenuStrip2;
                    TextEditor.Dock = DockStyle.Fill;
                    tabPage.Controls.Add(TextEditor);

                    TextEditor.BoxEditor.Language = Language.CSharp;
                    TextEditor.BoxEditor.Text = File.ReadAllText(create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".cs");
                    TextEditor.s.Visible = true;
                    
                    tabPage.Text = create.guna2TextBox1.Text + ".cs";
                    tabControl1.Controls.Add(tabPage);

                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;                    
                    TextEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    TextEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    TextEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    TextEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    TextEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    TextEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    TextEditor.Errorbtn.Text = "";

                    tabControl1.SelectedTab = tabPage;
                    TextEditor.s.Text = create.guna2TextBox1.Text + ".exe";
                    TextEditor.PathLabel.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text;
                    TextEditor.toolStripStatusLabel2.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".cs";
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    
                }
                else if (create.guna2ComboBox2.SelectedIndex == 1 && create.guna2ComboBox1.SelectedIndex == 0)
                {
                    Editor.Visible = true;                   
                    var TextEditor = new TextBoxEditor();
                    TextEditor.BoxEditor.ContextMenuStrip = contextMenuStrip2;
                    TextEditor.Dock = DockStyle.Fill;
                    tabPage.Controls.Add(TextEditor);
                    TextEditor.BoxEditor.Language = Language.VB;
                    TextEditor.s.Visible = true;
                    TextEditor.BoxEditor.Text = File.ReadAllText(create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".vb");
                    tabPage.Text = create.guna2TextBox1.Text + ".vb";
                    tabControl1.Controls.Add(tabPage);

                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;
                    TextEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    TextEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    TextEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    TextEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    TextEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    TextEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    TextEditor.Errorbtn.Text = "";

                    tabControl1.SelectedTab = tabPage;
                    TextEditor.s.Text = create.guna2TextBox1.Text + ".exe";
                    TextEditor.PathLabel.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text;
                    TextEditor.toolStripStatusLabel2.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".vb";
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    TextEditor.autocompleteMenu1.Items = File.ReadAllLines("Languges\\VisualBasic.dicr");
                }                
                else if (create.guna2ComboBox2.SelectedIndex == 0 && create.guna2ComboBox1.SelectedIndex == 1)
                {
                    Editor.Visible = true;                    
                    var TextEditor = new TextBoxEditor();
                    TextEditor.BoxEditor.ContextMenuStrip = contextMenuStrip2;
                    TextEditor.Dock = DockStyle.Fill;
                    tabPage.Controls.Add(TextEditor);
                    TextEditor.BoxEditor.Language = Language.HTML;
                    
                    TextEditor.BoxEditor.Text = File.ReadAllText(create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".html");
                    tabPage.Text = create.guna2TextBox1.Text + ".html";
                    tabControl1.Controls.Add(tabPage);

                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    TextEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;
                    TextEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    TextEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    TextEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    TextEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    TextEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    TextEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;

                    tabControl1.SelectedTab = tabPage;
                    TextEditor.PathLabel.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text;
                    TextEditor.toolStripStatusLabel2.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + "\\" + create.guna2TextBox1.Text + ".html";
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    TextEditor.guna2Panel6.Visible = false;
                    TextEditor.splitter3.Visible = false;
                    TextEditor.autocompleteMenu1.Items = File.ReadAllLines("Languges\\HTML.dicr");
                }
                else if (create.guna2ComboBox1.SelectedIndex == 2)
                {
                    Editor.Visible = true;                    
                    var TextEditor = new TextBoxEditor();
                    TextEditor.BoxEditor.ContextMenuStrip = contextMenuStrip2;
                    TextEditor.Dock = DockStyle.Fill;
                    tabPage.Controls.Add(TextEditor);
                    TextEditor.BoxEditor.Language = Language.Custom;

                    TextEditor.BoxEditor.Text = File.ReadAllText(create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + ".txt");
                    tabPage.Text = create.guna2TextBox1.Text + ".txt";
                    tabControl1.Controls.Add(tabPage);

                    TextEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    TextEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    TextEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;

                    tabControl1.SelectedTab = tabPage;
                    TextEditor.PathLabel.Text = create.guna2TextBox2.Text;
                    TextEditor.toolStripStatusLabel2.Text = create.guna2TextBox2.Text + "\\" + create.guna2TextBox1.Text + ".txt";
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    TextEditor.StartBtn.Visible = false;
                    TextEditor.PathLabel.Location = new Point(3, 5);
                    TextEditor.guna2Panel6.Visible = false;
                    TextEditor.splitter3.Visible = false;
                }
            }
        }

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Button1.PerformClick();
        }

        [Obsolete]
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog1.FileName.ToString();
                Editor.Visible = true;
                TextBoxEditor textBoxEditor = new TextBoxEditor();
                textBoxEditor.BoxEditor.ContextMenuStrip = contextMenuStrip2;
                textBoxEditor.Dock = DockStyle.Fill;
                Tab tabPage = new Tab();
                if (Properties.Settings.Default.Theme == 0)
                {
                    tabPage.BackColor = Color.White;
                    tabPage.ForeColor = Color.Black;
                }
                else if (Properties.Settings.Default.Theme == 1)
                {
                    tabPage.BackColor = Color.Gray;
                    tabPage.ForeColor = Color.White;
                }
                string filename = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);

                if (openFileDialog1.FilterIndex == 1)
                {
                    textBoxEditor.BoxEditor.Language = Language.CSharp;
                    textBoxEditor.BoxEditor.Text = File.ReadAllText(path);
                    textBoxEditor.toolStripStatusLabel2.Text = path;
                    tabPage.Controls.Add(textBoxEditor);
                    textBoxEditor.s.Visible = true;
                    tabPage.Text = filename + ".cs";
                    textBoxEditor.s.Text = filename + ".exe";
                    textBoxEditor.PathLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                    tabControl1.Controls.Add(tabPage);
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    tabControl1.SelectedTab = tabPage;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    textBoxEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    textBoxEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    textBoxEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    textBoxEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                }                
                else if (openFileDialog1.FilterIndex == 2)
                {
                    textBoxEditor.BoxEditor.Language = Language.VB;
                    textBoxEditor.BoxEditor.Text = File.ReadAllText(path);
                    tabPage.Controls.Add(textBoxEditor);
                    textBoxEditor.toolStripStatusLabel2.Text = path;
                    textBoxEditor.s.Visible = true;
                    tabPage.Text = filename + ".vb";
                    textBoxEditor.s.Text = filename + ".exe";
                    textBoxEditor.PathLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                    tabControl1.Controls.Add(tabPage);
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    tabControl1.SelectedTab = tabPage;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    textBoxEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    textBoxEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    textBoxEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    textBoxEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    textBoxEditor.autocompleteMenu1.Items = File.ReadAllLines("Languges\\VisualBasic.dicr");
                }        
                else if (openFileDialog1.FilterIndex == 4)
                {
                    textBoxEditor.BoxEditor.Language = Language.HTML;
                    textBoxEditor.BoxEditor.Text = File.ReadAllText(path);
                    tabPage.Controls.Add(textBoxEditor);
                    textBoxEditor.toolStripStatusLabel2.Text = path;
                    textBoxEditor.s.Visible = false;
                    tabPage.Text = filename + ".html";
                    textBoxEditor.PathLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                    tabControl1.Controls.Add(tabPage);
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    tabControl1.SelectedTab = tabPage;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedBackColor2 = Properties.Settings.Default.autocolor;
                    textBoxEditor.autocompleteMenu1.Colors.ForeColor = Properties.Settings.Default.autofore;
                    textBoxEditor.autocompleteMenu1.Colors.SelectedForeColor = Properties.Settings.Default.autoborder;
                    textBoxEditor.autocompleteMenu1.Colors.BackColor = Properties.Settings.Default.autonotselectbg;
                    textBoxEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    textBoxEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    textBoxEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    textBoxEditor.guna2Panel6.Visible = false;
                    textBoxEditor.splitter3.Visible = false;
                    textBoxEditor.autocompleteMenu1.Items = File.ReadAllLines("Languges\\HTML.dicr");
                }
                else if (openFileDialog1.FilterIndex == 5)
                {
                    textBoxEditor.BoxEditor.Language = Language.Custom;
                    textBoxEditor.BoxEditor.Text = File.ReadAllText(path);
                    tabPage.Controls.Add(textBoxEditor);
                    textBoxEditor.toolStripStatusLabel2.Text = path;
                    textBoxEditor.s.Visible = false;
                    tabPage.Text = filename + ".txt";
                    textBoxEditor.StartBtn.Visible = false;
                    textBoxEditor.PathLabel.Location = new Point(3, 5);
                    textBoxEditor.PathLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                    tabControl1.Controls.Add(tabPage);
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    tabControl1.SelectedTab = tabPage;
                    textBoxEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    textBoxEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    textBoxEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    textBoxEditor.guna2Panel6.Visible = false;
                    textBoxEditor.splitter3.Visible = false;
                }
                else if (openFileDialog1.FilterIndex == 6)
                {
                    textBoxEditor.BoxEditor.Language = Language.Custom;
                    textBoxEditor.BoxEditor.Text = File.ReadAllText(path);
                    tabPage.Controls.Add(textBoxEditor);
                    textBoxEditor.toolStripStatusLabel2.Text = path;
                    textBoxEditor.s.Visible = false;
                    tabPage.Text = filename;
                    textBoxEditor.StartBtn.Visible = false;
                    textBoxEditor.PathLabel.Location = new Point(3, 5);
                    textBoxEditor.PathLabel.Text = Path.GetDirectoryName(openFileDialog1.FileName);
                    tabControl1.Controls.Add(tabPage);
                    editToolStripMenuItem.Visible = true;
                    runToolStripMenuItem.Visible = true;
                    saveAllToolStripMenuItem.Visible = true;
                    saveToolStripMenuItem.Visible = true;
                    printPreviewToolStripMenuItem.Visible = true;
                    hotKeysToolStripMenuItem.Visible = true;
                    projectToolStripMenuItem.Visible = true;
                    tabControl1.SelectedTab = tabPage;
                    textBoxEditor.BoxEditor.BackColor = Properties.Settings.Default.editorback;
                    textBoxEditor.BoxEditor.ForeColor = Properties.Settings.Default.editorfore;
                    textBoxEditor.BoxEditor.SelectionColor = Properties.Settings.Default.editorsel;
                    textBoxEditor.guna2Panel6.Visible = false;
                    textBoxEditor.splitter3.Visible = false;
                }               
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            guna2Button2.PerformClick();
        }

        [Obsolete]
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Tab tabPage = new Tab();

            if (tabControl1.Tabs.Contains(tabPage))
            {
                tabControl1.SelectedTab.Contains(tabPage);  
            }
        }

        [Obsolete]
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tab seltab = tabControl1.SelectedTab;
            string selecttabname = seltab.Text;

            TextBoxEditor boxEditor = new TextBoxEditor();

            if (boxEditor.toolStripStatusLabel2.Text.Contains("\\"))
            {                
                Tab tabpage = tabControl1.SelectedTab;
                if (tabpage.Text.Contains(selecttabname))
                {
                    var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                    File.WriteAllText(pub.toolStripStatusLabel2.Text, pub.BoxEditor.Text);
                    StreamWriter strwriter = File.AppendText(pub.toolStripStatusLabel2.Text);
                    strwriter.Close();
                }
            }
            else
            {
                
            }
        }


        [Obsolete]
        private void saveAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                Manina.Windows.Forms.TabControl.TabCollection tabcoll = tabControl1.Tabs;

                foreach (Tab tabpage in tabcoll)
                {
                    tabControl1.SelectedTab = tabpage;

                    if (!tabpage.Text.Contains("NewProject"))
                    {
                        try
                        {
                            var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                            File.WriteAllText(pub.toolStripStatusLabel2.Text, pub.BoxEditor.Text);
                            StreamWriter strwriter = File.AppendText(pub.toolStripStatusLabel2.Text);
                            strwriter.Close();
                        }
                        catch 
                        { 

                        }
                    }
                }

                Manina.Windows.Forms.TabControl.TabCollection tabcollection = tabControl1.Tabs;
                foreach (Tab tabpage in tabcollection)
                {
                    string str = tabpage.Text;
                    if (str.Contains("*") && !str.Contains("NewProject"))
                    {
                        str = str.Remove(str.Length - 1);
                    }
                    tabpage.Text = str;
                }
            }
        }

        [Obsolete]
        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                if (pageSetupDialog1.ShowDialog() == DialogResult.OK)
                {                    
                    pageSetupDialog1.Document.Print();
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                saveAllToolStripMenuItem.PerformClick();
                Tab tabpage = tabControl1.SelectedTab;
                saveToolStripMenuItem.PerformClick();
                tabControl1.Tabs.Remove(tabpage);
            }
            if (tabControl1.Tabs.Count == 0)
            {
                MainPanel.Visible = true;
                Editor.Visible = false;
                MessageBox.Show(MyStrings._3text, MyStrings._3title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                editToolStripMenuItem.Visible = false;
                runToolStripMenuItem.Visible = false;
                saveAllToolStripMenuItem.Visible = false;
                saveToolStripMenuItem.Visible = false;
                printPreviewToolStripMenuItem.Visible = false;
                hotKeysToolStripMenuItem.Visible = false;
                projectToolStripMenuItem.Visible = false;
            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                pub.BoxEditor.Undo();        
            }
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                pub.BoxEditor.Redo();
            }            
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                if (pub.BoxEditor.SelectedText != "")
                {
                    if (Clipboard.ContainsText())
                    {
                        Clipboard.Clear();
                        Clipboard.SetText(pub.BoxEditor.SelectedText);
                    }
                    else
                    {
                        Clipboard.SetText(pub.BoxEditor.SelectedText);
                    }
                }
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];

                if (Clipboard.ContainsText())
                {
                    pub.BoxEditor.Paste();
                }
            }
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                if (pub.BoxEditor.SelectedText != "")
                {
                    if (Clipboard.ContainsText())
                    {
                        Clipboard.Clear();
                        Clipboard.SetText(pub.BoxEditor.SelectedText);
                        pub.BoxEditor.SelectedText = "";
                    }
                    else
                    {
                        Clipboard.SetText(pub.BoxEditor.SelectedText);
                        pub.BoxEditor.SelectedText = "";
                    }
                }
            }
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                pub.BoxEditor.SelectAll();
            }
        }

        private void closeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.Tabs.Clear();

            if (tabControl1.Tabs.Count == 0)
            {
                MainPanel.Visible = true;
                Editor.Visible = false;
                MessageBox.Show(MyStrings._3text, MyStrings._3title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                editToolStripMenuItem.Visible = false;
                runToolStripMenuItem.Visible = false;
                saveAllToolStripMenuItem.Visible = false;
                saveToolStripMenuItem.Visible = false;
                printPreviewToolStripMenuItem.Visible = false;              
                hotKeysToolStripMenuItem.Visible = false;
                projectToolStripMenuItem.Visible = false;
            }
        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveToolStripMenuItem.PerformClick();
        }

        private void saveAllToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveAllToolStripMenuItem.PerformClick();
        }

        private void copyPathToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                if (Clipboard.ContainsText())
                {
                    Clipboard.Clear();
                    Clipboard.SetText(pub.toolStripStatusLabel2.Text);
                }
                else
                {
                    Clipboard.SetText(pub.toolStripStatusLabel2.Text);
                }


            }
        }
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            cutToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            pasteToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            copyToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            undoToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            redoToolStripMenuItem.PerformClick();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            selectAllToolStripMenuItem.PerformClick();
        }

        private void googleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://google.com");
        }

        private void googleTranslateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://translate.google.com");
        }

        private void windowsExplorerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("C:\\Windows\\explorer.exe");
        }

        private void runConsoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                pub.StartBtn.PerformClick();
            }
        }
        [Obsolete]
        private void settingsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();           
            settings.ShowDialog();
        }

        private void buildToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                if (tabControl1.Tabs.Count > 0)
                {
                    if (pub.BoxEditor.Language != Language.HTML)
                    {
                        string dirpath = pub.PathLabel.Text + "\\" + pub.s.Text;
                        DirectoryInfo directory = new DirectoryInfo(pub.PathLabel.Text + "\\" + "Build");
                        string path = pub.PathLabel.Text + "\\" + "Build" + "\\" + pub.s.Text;
                        if (!directory.Exists)
                        {
                            if (pub.BoxEditor.Language != Language.HTML)
                            {
                                if (!File.Exists(dirpath))
                                {
                                    MessageBox.Show(MyStrings._4text, MyStrings._4title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                if (File.Exists(dirpath))
                                {
                                    if (!File.Exists(path))
                                    {
                                        directory.Create();
                                        File.Move(dirpath, path);
                                        MessageBox.Show(MyStrings._5text + pub.PathLabel.Text + "\\" + "Build" + "\\" + pub.s.Text, MyStrings._5title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                        else if (directory.Exists)
                        {
                            Directory.Delete(pub.PathLabel.Text + "\\" + "Build", true);

                            if (pub.BoxEditor.Language != Language.HTML)
                            {
                                if (!File.Exists(dirpath))
                                {
                                    MessageBox.Show(MyStrings._4text, MyStrings._4title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                if (File.Exists(dirpath))
                                {
                                    if (!File.Exists(path))
                                    {
                                        directory.Create();
                                        File.Move(dirpath, path);
                                        MessageBox.Show(MyStrings._5text + pub.PathLabel.Text + "\\" + "Build" + "\\" + pub.s.Text, MyStrings._5title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }

                    }
                    else if (pub.BoxEditor.Language == Language.HTML)
                    {
                        MessageBox.Show(MyStrings._6text, MyStrings._6title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void zipBuildToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                if (tabControl1.Tabs.Count > 0)
                {
                    
                    if (pub.BoxEditor.Language != Language.HTML)
                    {
                        string dirpath = pub.PathLabel.Text + "\\" + pub.s.Text;
                        DirectoryInfo directory = new DirectoryInfo(pub.PathLabel.Text + "\\" + "ZipBuild");
                        string path = pub.PathLabel.Text + "\\" + "ZipBuild" + "\\" + pub.s.Text;
                        if (!directory.Exists)
                        {
                            if (pub.BoxEditor.Language != Language.HTML)
                            {
                                if (!File.Exists(dirpath))
                                {
                                    MessageBox.Show(MyStrings._4text, MyStrings._4title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                if (File.Exists(dirpath))
                                {
                                    if (!File.Exists(path))
                                    {
                                        string StartPath = directory.ToString();
                                        string ZipPath = pub.PathLabel.Text + "\\" + "ZipBuild.zip";
                                        directory.Create();
                                        File.Move(dirpath, path);
                                        ZipFile.CreateFromDirectory(StartPath, ZipPath);
                                        Directory.Delete(pub.PathLabel.Text + "\\" + "ZipBuild", true);
                                        MessageBox.Show(MyStrings._5text + pub.PathLabel.Text + "\\" + "ZipBuild.zip" + "\\" + pub.s.Text, MyStrings._5title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }
                        else if (directory.Exists)
                        {
                            Directory.Delete(pub.PathLabel.Text + "\\" + "ZipBuild", true);

                            if (pub.BoxEditor.Language != Language.HTML)
                            {
                                if (!File.Exists(dirpath))
                                {
                                    MessageBox.Show(MyStrings._4text, MyStrings._4title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                if (File.Exists(dirpath))
                                {
                                    if (!File.Exists(path))
                                    {
                                        string StartPath = directory.ToString();
                                        string ZipPath = pub.PathLabel.Text + "\\" + "ZipBuild.zip";
                                        directory.Create();                                       
                                        File.Move(dirpath, path);
                                        ZipFile.CreateFromDirectory(StartPath, ZipPath);
                                        Directory.Delete(pub.PathLabel.Text + "\\" + "ZipBuild", true);
                                        MessageBox.Show(MyStrings._5text + pub.PathLabel.Text + "\\" + "ZipBuild.zip" + "\\" + pub.s.Text, MyStrings._5title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                            }
                        }

                    }
                    else if (pub.BoxEditor.Language == Language.HTML)
                    {
                        MessageBox.Show(MyStrings._6text, MyStrings._6title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void rightToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            guna2Panel1.Dock = DockStyle.Right;
            splitter1.Dock = DockStyle.Right;
            splitter1.Cursor = Cursors.SizeWE;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void leftToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            guna2Panel1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            splitter1.Cursor = Cursors.SizeWE;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Save();
        }

        private void resetToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            guna2Panel1.Size = new Size(180, 336);
            guna2Panel1.Dock = DockStyle.Left;
            splitter1.Dock = DockStyle.Left;
            Properties.Settings.Default.PanelDock = guna2Panel1.Dock;
            Properties.Settings.Default.PanelDock = splitter1.Dock;
            Properties.Settings.Default.Splitter = guna2Panel1.Size;
            Properties.Settings.Default.Save();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                e.Graphics.DrawString(pub.BoxEditor.Text, pub.BoxEditor.Font, Brushes.Black, e.MarginBounds.Left, 0, new StringFormat());
            }
        }

        private void documentationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string filename = Application.StartupPath + "\\Qensy Studio Documentation.pdf";
            if (File.Exists(filename))
            {
                Process.Start(filename);
            }
            else if (!File.Exists(filename))
            {
                MessageBox.Show("Error: 010QSx1\nThere is no documentation file!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void hotKeysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                var hotkeys_form = new HotkeysEditorForm(pub.BoxEditor.HotkeysMapping);
                if (hotkeys_form.ShowDialog() == DialogResult.OK)
                {
                    pub.BoxEditor.HotkeysMapping = hotkeys_form.GetHotkeys();
                }
            }
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            if (OpenPicture.ShowDialog() == DialogResult.Cancel)
                return;
            string path = OpenPicture.FileName;
            guna2PictureBox1.ImageLocation = path;
            Properties.Settings.Default.Picture = guna2PictureBox1.ImageLocation;
            Properties.Settings.Default.Save();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            guna2PictureBox1.ImageLocation = null;
            Properties.Settings.Default.Picture = guna2PictureBox1.ImageLocation;
            Properties.Settings.Default.Save();
        }

        private void topLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.TopLeft;
            Properties.Settings.Default.tab = TabLocation.TopLeft;
            Properties.Settings.Default.Save();
        }

        private void topCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.TopCenter;
            Properties.Settings.Default.tab = TabLocation.TopCenter;
            Properties.Settings.Default.Save();
        }

        private void topRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.TopRight;
            Properties.Settings.Default.tab = TabLocation.TopRight;
            Properties.Settings.Default.Save();
        }

        private void rightTopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.RightTop;
            Properties.Settings.Default.tab = TabLocation.RightTop;
            Properties.Settings.Default.Save();
        }

        private void rightCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.RightCenter;
            Properties.Settings.Default.tab = TabLocation.RightCenter;
            Properties.Settings.Default.Save();
        }

        private void rightBottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.RightBottom;
            Properties.Settings.Default.tab = TabLocation.RightBottom;
            Properties.Settings.Default.Save();
        }

        private void bottomRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.BottomRight;
            Properties.Settings.Default.tab = TabLocation.BottomRight;
            Properties.Settings.Default.Save();
        }

        private void bottomCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.BottomCenter;
            Properties.Settings.Default.tab = TabLocation.BottomCenter;
            Properties.Settings.Default.Save();
        }

        private void bottomLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.BottomLeft;
            Properties.Settings.Default.tab = TabLocation.BottomLeft;
            Properties.Settings.Default.Save();
        }

        private void leftBottomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.LeftBottom;
            Properties.Settings.Default.tab = TabLocation.LeftBottom;
            Properties.Settings.Default.Save();
        }

        private void leftCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {

            tabControl1.TabLocation = TabLocation.LeftCenter;
            Properties.Settings.Default.tab = TabLocation.LeftCenter;
            Properties.Settings.Default.Save();
        }

        private void leftTopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.TabLocation = TabLocation.LeftTop;
            Properties.Settings.Default.tab = TabLocation.LeftTop;
            Properties.Settings.Default.Save();
        }

        private void openInExplorerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.Tabs.Count > 0)
            {
                var pub = (TextBoxEditor)tabControl1.Tabs[tabControl1.SelectedIndex].Controls[0];
                Process.Start("explorer", pub.PathLabel.Text);
            }
        }
    }
}